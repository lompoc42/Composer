"""
Binding resolution layer.

Takes a Project's bindings + external files and produces a flat dict of
resolved values ready to substitute into markdown.

Binding kinds:
  literal         -> spec["value"]              (raw string/number)
  file_text       -> entire text of source file (markdown/txt)
  file_table      -> render rows from CSV/Excel as a markdown table
                       spec: {sheet?: str, columns?: [str], max_rows?: int}
  expression      -> evaluate an expression against source file
                       spec: {expr: "count_where(col='Status', value='YES') / row_count()"}

Expressions are evaluated in a sandbox with a fixed function registry.
No eval(), no exec(). Add functions by registering them.
"""

from dataclasses import dataclass
from pathlib import Path
import ast
import operator as op

import pandas as pd

from project import Project, Binding


# ---------- expression sandbox ----------

_BIN_OPS = {
    ast.Add: op.add, ast.Sub: op.sub, ast.Mult: op.mul,
    ast.Div: op.truediv, ast.FloorDiv: op.floordiv, ast.Mod: op.mod,
    ast.Pow: op.pow,
}
_UNARY_OPS = {ast.UAdd: op.pos, ast.USub: op.neg}


class ExprFunctions:
    """Functions available inside expressions.

    Functions starting with `_df_` receive the loaded DataFrame as the first
    positional arg (injected by the resolver). All other functions are pure
    and called with user args only.
    """

    # ---- df-aware ----
    @staticmethod
    def _df_row_count(df: pd.DataFrame) -> int:
        return len(df)

    @staticmethod
    def _df_col_count(df: pd.DataFrame) -> int:
        return df.shape[1]

    @staticmethod
    def _df_count_where(df: pd.DataFrame, col: str, value) -> int:
        return int((df[col] == value).sum())

    @staticmethod
    def _df_sum_col(df: pd.DataFrame, col: str) -> float:
        return float(pd.to_numeric(df[col], errors="coerce").sum())

    @staticmethod
    def _df_mean_col(df: pd.DataFrame, col: str) -> float:
        return float(pd.to_numeric(df[col], errors="coerce").mean())

    @staticmethod
    def _df_min_col(df: pd.DataFrame, col: str) -> float:
        return float(pd.to_numeric(df[col], errors="coerce").min())

    @staticmethod
    def _df_max_col(df: pd.DataFrame, col: str) -> float:
        return float(pd.to_numeric(df[col], errors="coerce").max())

    # ---- pure ----
    @staticmethod
    def percent(numerator, denominator, decimals: int = 1) -> str:
        if denominator == 0:
            return "N/A"
        return f"{(numerator / denominator) * 100:.{decimals}f}%"

    @staticmethod
    def round_to(value, decimals: int = 0):
        return round(value, decimals)


def _public_name(internal_name: str) -> str:
    return internal_name[4:] if internal_name.startswith("_df_") else internal_name


_REGISTRY = {}
_DF_AWARE: set = set()
for _name in dir(ExprFunctions):
    if _name.startswith("__"):
        continue
    _public = _public_name(_name)
    _REGISTRY[_public] = getattr(ExprFunctions, _name)
    if _name.startswith("_df_"):
        _DF_AWARE.add(_public)


def _eval_node(node, df: pd.DataFrame):
    """Walk an AST and evaluate. Only allow constants, names from registry,
    function calls into the registry, arithmetic, and basic literals."""
    if isinstance(node, ast.Constant):
        return node.value
    if isinstance(node, ast.BinOp):
        return _BIN_OPS[type(node.op)](_eval_node(node.left, df), _eval_node(node.right, df))
    if isinstance(node, ast.UnaryOp):
        return _UNARY_OPS[type(node.op)](_eval_node(node.operand, df))
    if isinstance(node, ast.Call):
        if not isinstance(node.func, ast.Name):
            raise ValueError("Only direct function calls allowed")
        fn_name = node.func.id
        if fn_name not in _REGISTRY:
            raise ValueError(f"Unknown function: {fn_name}")
        args = [_eval_node(a, df) for a in node.args]
        kwargs = {kw.arg: _eval_node(kw.value, df) for kw in node.keywords}
        if fn_name in _DF_AWARE:
            return _REGISTRY[fn_name](df, *args, **kwargs)
        return _REGISTRY[fn_name](*args, **kwargs)
    if isinstance(node, ast.Name):
        # Bare names not allowed (no variables); only function calls.
        raise ValueError(f"Bare name not allowed: {node.id}")
    raise ValueError(f"Disallowed expression node: {type(node).__name__}")


def evaluate_expr(expr: str, df: pd.DataFrame):
    tree = ast.parse(expr, mode="eval")
    return _eval_node(tree.body, df)


# ---------- file loaders ----------

def _load_dataframe(path: Path, sheet: str | None = None) -> pd.DataFrame:
    suffix = path.suffix.lower()
    if suffix in (".csv", ".tsv"):
        sep = "," if suffix == ".csv" else "\t"
        return pd.read_csv(path, sep=sep)
    if suffix in (".xlsx", ".xls"):
        return pd.read_excel(path, sheet_name=sheet or 0)
    raise ValueError(f"Unsupported tabular file type: {suffix}")


def _df_to_md_table(df: pd.DataFrame, columns=None, max_rows: int | None = None) -> str:
    if columns:
        df = df[columns]
    if max_rows:
        df = df.head(max_rows)
    return df.to_markdown(index=False)


# ---------- resolver ----------

@dataclass
class ResolutionError:
    binding: str
    message: str


def resolve_bindings(proj: Project) -> tuple[dict, list[ResolutionError]]:
    """Resolve all bindings -> (values_dict, errors). Errors don't halt resolution;
    failed bindings get a visible error sentinel so the doc renders with markers."""
    out: dict = {}
    errors: list[ResolutionError] = []

    for name, b in proj.bindings.items():
        try:
            out[name] = _resolve_one(b, proj)
        except Exception as e:
            errors.append(ResolutionError(binding=name, message=str(e)))
            out[name] = f"⚠️[{name}: {e}]"

    return out, errors


def _resolve_one(b: Binding, proj: Project):
    if b.kind == "literal":
        return b.spec.get("value", "")

    if b.kind == "file_text":
        path = proj.external_dir / b.source
        return path.read_text(encoding="utf-8")

    if b.kind == "file_table":
        path = proj.external_dir / b.source
        df = _load_dataframe(path, sheet=b.spec.get("sheet"))
        return _df_to_md_table(df, columns=b.spec.get("columns"),
                               max_rows=b.spec.get("max_rows"))

    if b.kind == "expression":
        path = proj.external_dir / b.source
        df = _load_dataframe(path, sheet=b.spec.get("sheet"))
        return evaluate_expr(b.spec["expr"], df)

    raise ValueError(f"Unknown binding kind: {b.kind}")


# ---------- smoke test ----------

def _make_test_project() -> Project:
    root = Path("/home/claude/mdproj/projects/_resolve_test")
    proj = Project.create(root)

    # External CSV
    csv_path = proj.external_dir / "responses.csv"
    pd.DataFrame({
        "respondent": ["A", "B", "C", "D", "E"],
        "Status": ["YES", "NO", "YES", "YES", "NO"],
        "score": [10, 20, 30, 40, 50],
    }).to_csv(csv_path, index=False)

    # External text file
    (proj.external_dir / "blurb.md").write_text("Imported blurb text.")

    proj.bindings = {
        "client_name": Binding(name="client_name", kind="literal",
                               spec={"value": "Acme Industrial"}),
        "yes_rate": Binding(name="yes_rate", kind="expression",
                            source="responses.csv",
                            spec={"expr": "percent(count_where(col='Status', value='YES'), row_count())"}),
        "score_avg": Binding(name="score_avg", kind="expression",
                             source="responses.csv",
                             spec={"expr": "mean_col(col='score')"}),
        "blurb": Binding(name="blurb", kind="file_text", source="blurb.md"),
        "responses_table": Binding(name="responses_table", kind="file_table",
                                   source="responses.csv",
                                   spec={"max_rows": 3}),
        "broken": Binding(name="broken", kind="expression",
                          source="responses.csv",
                          spec={"expr": "count_where(col='NotARealColumn', value='X')"}),
    }
    proj.save()
    return proj


def run(cfg=None):
    proj = _make_test_project()
    values, errors = resolve_bindings(proj)
    print("Resolved values:")
    for k, v in values.items():
        preview = str(v).replace("\n", " | ")[:80]
        print(f"  {k}: {preview}")
    print(f"\nErrors ({len(errors)}):")
    for e in errors:
        print(f"  - {e.binding}: {e.message}")


if __name__ == "__main__":
    run()
