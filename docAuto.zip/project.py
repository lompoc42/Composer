"""
Project structure for the markdown-canonical document system.

A project is a folder:
    project_name/
        doc.md              # canonical markdown (source of truth)
        bindings.json       # variable bindings + expressions
        template.docx       # render style template (pandoc reference doc)
        assets/             # extracted images, charts, etc.
        external/           # linked external data files (Excel, CSV, docx)
        import_report.json  # one-time, written by Word importer

Bindings live in bindings.json, keyed by tag name. The markdown contains
{{tag_name}} placeholders. Render = jinja-substitute bindings -> pandoc.
"""

from dataclasses import dataclass, field, asdict
from pathlib import Path
import json

_DEFAULTS = {
    "project_root": "/home/claude/mdproj/projects",
    "doc_filename": "doc.md",
    "bindings_filename": "bindings.json",
    "template_filename": "template.docx",
    "assets_dirname": "assets",
    "external_dirname": "external",
    "import_report_filename": "import_report.json",
}


@dataclass
class Binding:
    """A single tagged variable in the document.

    kind: 'literal' | 'file_text' | 'file_table' | 'expression'
    source: path to external file (if applicable), relative to project/external/
    spec: kind-specific config (e.g. expression string, column name, sheet)
    original_text: the verbatim text the user highlighted when creating this
        binding. Used to restore the doc if the binding is deleted.
    """
    name: str
    kind: str
    source: str | None = None
    spec: dict = field(default_factory=dict)
    description: str = ""
    original_text: str = ""


@dataclass
class Project:
    root: Path
    bindings: dict[str, Binding] = field(default_factory=dict)

    # ---- paths ----
    @property
    def doc_path(self) -> Path:
        return self.root / _DEFAULTS["doc_filename"]

    @property
    def bindings_path(self) -> Path:
        return self.root / _DEFAULTS["bindings_filename"]

    @property
    def template_path(self) -> Path:
        return self.root / _DEFAULTS["template_filename"]

    @property
    def assets_dir(self) -> Path:
        return self.root / _DEFAULTS["assets_dirname"]

    @property
    def external_dir(self) -> Path:
        return self.root / _DEFAULTS["external_dirname"]

    @property
    def import_report_path(self) -> Path:
        return self.root / _DEFAULTS["import_report_filename"]

    # ---- lifecycle ----
    @classmethod
    def create(cls, root: Path) -> "Project":
        root = Path(root)
        root.mkdir(parents=True, exist_ok=True)
        (root / _DEFAULTS["assets_dirname"]).mkdir(exist_ok=True)
        (root / _DEFAULTS["external_dirname"]).mkdir(exist_ok=True)
        proj = cls(root=root)
        if not proj.doc_path.exists():
            proj.doc_path.write_text("", encoding="utf-8")
        proj.save()
        return proj

    @classmethod
    def load(cls, root: Path) -> "Project":
        root = Path(root)
        proj = cls(root=root)
        if proj.bindings_path.exists():
            data = json.loads(proj.bindings_path.read_text(encoding="utf-8"))
            proj.bindings = {
                name: Binding(**b) for name, b in data.get("bindings", {}).items()
            }
        return proj

    def save(self) -> None:
        payload = {"bindings": {n: asdict(b) for n, b in self.bindings.items()}}
        self.bindings_path.write_text(json.dumps(payload, indent=2, ensure_ascii=False), encoding="utf-8")

    # ---- doc text ----
    def read_doc(self) -> str:
        return self.doc_path.read_text(encoding="utf-8") if self.doc_path.exists() else ""

    def write_doc(self, text: str) -> None:
        self.doc_path.write_text(text, encoding="utf-8")

    # ---- bindings ----
    def set_binding(self, b: Binding) -> None:
        self.bindings[b.name] = b
        self.save()

    def remove_binding(self, name: str) -> None:
        self.bindings.pop(name, None)
        self.save()


def run(cfg=None):
    cfg = {**_DEFAULTS, **(cfg or {})}
    test_root = Path(cfg["project_root"]) / "_smoketest"
    proj = Project.create(test_root)
    proj.write_doc("# Hello\n\nValue: {{my_var}}\n")
    proj.set_binding(Binding(name="my_var", kind="literal", spec={"value": "42"}))
    reloaded = Project.load(test_root)
    assert reloaded.bindings["my_var"].spec["value"] == "42"
    assert reloaded.read_doc().strip().endswith("{{my_var}}")
    print(f"OK: project at {test_root}")
    print(f"  bindings: {list(reloaded.bindings)}")


if __name__ == "__main__":
    run()
