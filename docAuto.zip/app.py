"""
Flask backend for the markdown doc composer.

Serves a single-page UI and exposes a small JSON API on top of the existing
library (project.py / resolver.py / renderer.py / word_import.py).

Run:
    python app.py
"""

# ---------------------------------------------------------------------------
# Bulletproof local-module loading.
#
# Several PyPI packages ship modules named 'resolver', 'importer', etc., and
# they end up in our venv's site-packages as transitive dependencies. Even
# with the script's directory at sys.path[0], some Python configurations
# (particularly conda+venv on macOS) end up resolving these against
# site-packages instead of our local files.
#
# Fix: explicitly load each local module from its absolute file path BEFORE
# any `from X import Y` statements run. This pins them in sys.modules so all
# subsequent imports find OUR files no matter what's in site-packages.
# ---------------------------------------------------------------------------
import sys
import os
import importlib.util

_HERE = os.path.dirname(os.path.abspath(__file__))


def _load_local(name: str):
    path = os.path.join(_HERE, name + ".py")
    if not os.path.exists(path):
        raise ImportError(f"local module {name}.py not found at {path}")
    spec = importlib.util.spec_from_file_location(name, path)
    module = importlib.util.module_from_spec(spec)
    sys.modules[name] = module  # cache before exec_module so cross-imports work
    spec.loader.exec_module(module)
    return module


# Order matters: load dependency-free modules first.
for _modname in ("project", "word_import", "resolver", "renderer"):
    _load_local(_modname)

# ---------------------------------------------------------------------------

import re
import io
import json
import tempfile

from flask import Flask, request, jsonify, send_file, send_from_directory

from project import Project, Binding
from word_import import import_docx
from resolver import resolve_bindings, _REGISTRY as EXPR_FUNCS
from renderer import render, _find_tags, _find_loop_vars
import pandas as pd

from pathlib import Path

app = Flask(__name__)
HERE = Path(_HERE)
PROJECTS_ROOT = HERE / "projects"
PROJECTS_ROOT.mkdir(parents=True, exist_ok=True)


@app.route("/codemirror.bundle.js")
def codemirror_bundle():
    p = HERE / "codemirror.bundle.js"
    if not p.exists():
        return ("codemirror.bundle.js missing — re-download and place next to app.py", 500)
    return send_file(p, mimetype="application/javascript")


@app.errorhandler(Exception)
def _json_errors(e):
    """All uncaught errors should be JSON, not HTML — so the frontend can show
    them properly rather than choking on '<' in the response."""
    import traceback
    tb = traceback.format_exc()
    print(f"\n!!! UNHANDLED ERROR:\n{tb}\n", flush=True)
    code = getattr(e, "code", 500)
    return jsonify({"error": str(e), "traceback": tb}), code


# --------------------------------------------------------------- helpers

def _proj(name: str) -> Project:
    root = PROJECTS_ROOT / name
    if not root.exists():
        raise FileNotFoundError(name)
    return Project.load(root)


def _binding_to_dict(b: Binding) -> dict:
    return {
        "name": b.name, "kind": b.kind, "source": b.source,
        "spec": b.spec, "description": b.description,
        "original_text": b.original_text,
    }


def _project_state(proj: Project) -> dict:
    """Everything the frontend needs in one shot."""
    doc = proj.read_doc()
    values, errors = resolve_bindings(proj)
    return {
        "name": proj.root.name,
        "doc": doc,
        "bindings": {n: _binding_to_dict(b) for n, b in proj.bindings.items()},
        "resolved": {k: str(v) for k, v in values.items()},
        "errors": [{"binding": e.binding, "message": e.message} for e in errors],
        "external_files": sorted(p.name for p in proj.external_dir.iterdir() if p.is_file()),
        "expr_functions": sorted(EXPR_FUNCS.keys()),
        "tags_in_doc": sorted(_find_tags(doc)),
        "loop_vars_in_doc": sorted(_find_loop_vars(doc)),
    }


def _reconcile_orphans(proj: Project) -> int:
    """If a binding's tag no longer appears in the doc, restore its original_text
    in place of... well, it's not in the doc anymore. So we just delete the
    orphan binding. The doc already reflects whatever the user typed.

    But if the user deleted the {{tag}} pill, we want the original_text BACK.
    Heuristic: when a binding's tag is missing AND original_text is set, this
    is a deletion. We can't know where to put the text back without an anchor,
    so we just drop the binding. The user's edit wins.

    Returns: count of orphans removed.
    """
    doc = proj.read_doc()
    tags = _find_tags(doc)
    tag_roots = {t.split(".")[0] for t in tags}
    orphans = [n for n in proj.bindings if n not in tag_roots]
    for n in orphans:
        del proj.bindings[n]
    if orphans:
        proj.save()
    return len(orphans)


_TAG_NAME_RE = re.compile(r"^[a-zA-Z_][a-zA-Z0-9_]*$")


def _safe_tag_name(s: str, existing: set[str]) -> str:
    """Sanitize a string into a valid tag name; ensure uniqueness."""
    base = re.sub(r"[^a-zA-Z0-9_]", "_", s.strip()).strip("_") or "tag"
    if base[0].isdigit():
        base = "t_" + base
    base = base[:40]
    if base not in existing:
        return base
    i = 2
    while f"{base}_{i}" in existing:
        i += 1
    return f"{base}_{i}"


# --------------------------------------------------------------- routes: page

@app.route("/")
def index():
    return send_from_directory(HERE, "index.html")


# --------------------------------------------------------------- routes: projects

@app.route("/api/projects", methods=["GET"])
def list_projects():
    names = sorted(p.name for p in PROJECTS_ROOT.iterdir()
                   if p.is_dir() and not p.name.startswith("_"))
    return jsonify({"projects": names})


@app.route("/api/projects", methods=["POST"])
def create_project():
    name = (request.json or {}).get("name", "").strip()
    if not name or not re.match(r"^[a-zA-Z0-9_\- ]+$", name):
        return jsonify({"error": "Invalid name"}), 400
    target = PROJECTS_ROOT / name
    if target.exists():
        return jsonify({"error": "Already exists"}), 409
    proj = Project.create(target)
    return jsonify(_project_state(proj))


@app.route("/api/projects/import", methods=["POST"])
def import_project():
    name = request.form.get("name", "").strip()
    f = request.files.get("docx")
    if not name or not f:
        return jsonify({"error": "Missing name or file"}), 400
    target = PROJECTS_ROOT / name
    if target.exists():
        return jsonify({"error": "Already exists"}), 409
    with tempfile.NamedTemporaryFile(suffix=".docx", delete=False) as tmp:
        f.save(tmp.name)
        tmp_path = Path(tmp.name)
    try:
        try:
            proj, rpt = import_docx(tmp_path, target, "gfm+pipe_tables+raw_html")
        except Exception as e:
            # Roll back partial project folder so user can retry
            import shutil
            if target.exists():
                shutil.rmtree(target, ignore_errors=True)
            import traceback
            tb = traceback.format_exc()
            print(f"\n!!! IMPORT FAILED for {name}:\n{tb}\n", flush=True)
            return jsonify({"error": f"Import failed: {e}", "traceback": tb}), 500
    finally:
        tmp_path.unlink(missing_ok=True)
    state = _project_state(proj)
    state["import_report"] = {
        "paragraphs": rpt.paragraphs, "tables": rpt.tables,
        "complex_tables": rpt.complex_tables, "images": rpt.images,
        "headers": rpt.headers, "footers": rpt.footers,
        "text_boxes": rpt.text_boxes, "charts": rpt.charts,
        "equations": rpt.equations, "notes": rpt.notes,
    }
    return jsonify(state)


@app.route("/api/projects/<name>", methods=["GET"])
def load_project(name):
    return jsonify(_project_state(_proj(name)))


@app.route("/api/projects/<name>/doc", methods=["PUT"])
def save_doc(name):
    proj = _proj(name)
    text = (request.json or {}).get("doc", "")
    proj.write_doc(text)
    removed = _reconcile_orphans(proj)
    state = _project_state(proj)
    state["orphans_removed"] = removed
    return jsonify(state)


# --------------------------------------------------------------- routes: bindings

@app.route("/api/projects/<name>/bindings", methods=["POST"])
def create_binding(name):
    """Create a binding from a text selection.

    Body:
      doc:        full current doc text
      sel_start:  selection start char index
      sel_end:    selection end char index
      kind:       binding kind
      source:     external filename (optional)
      spec:       kind-specific config
      tag_name:   optional explicit name; otherwise auto-derived from selection

    Replaces doc[sel_start:sel_end] with `{{tag_name}}` and saves binding with
    original_text = the replaced text. Returns updated state and the new doc.
    """
    proj = _proj(name)
    body = request.json or {}
    doc = body["doc"]
    s, e = int(body["sel_start"]), int(body["sel_end"])
    if not (0 <= s <= e <= len(doc)):
        return jsonify({"error": "bad selection"}), 400
    selected = doc[s:e]

    existing_names = set(proj.bindings.keys())
    requested = (body.get("tag_name") or "").strip()
    if requested:
        if not _TAG_NAME_RE.match(requested):
            return jsonify({"error": "tag name must match [a-zA-Z_][a-zA-Z0-9_]*"}), 400
        if requested in existing_names:
            return jsonify({"error": f"tag name '{requested}' already in use"}), 409
        tag_name = requested
    else:
        tag_name = _safe_tag_name(selected or "tag", existing_names)

    new_doc = doc[:s] + "{{" + tag_name + "}}" + doc[e:]
    proj.write_doc(new_doc)
    proj.set_binding(Binding(
        name=tag_name,
        kind=body.get("kind", "literal"),
        source=body.get("source"),
        spec=body.get("spec", {}),
        description=body.get("description", ""),
        original_text=selected,
    ))
    state = _project_state(proj)
    state["new_tag_name"] = tag_name
    return jsonify(state)


@app.route("/api/projects/<name>/bindings/<tag>", methods=["PUT"])
def update_binding(name, tag):
    proj = _proj(name)
    body = request.json or {}
    if tag not in proj.bindings:
        return jsonify({"error": "no such binding"}), 404
    existing = proj.bindings[tag]
    proj.set_binding(Binding(
        name=tag,
        kind=body.get("kind", existing.kind),
        source=body.get("source", existing.source),
        spec=body.get("spec", existing.spec),
        description=body.get("description", existing.description),
        original_text=existing.original_text,
    ))
    return jsonify(_project_state(proj))


@app.route("/api/projects/<name>/bindings/<tag>", methods=["DELETE"])
def delete_binding(name, tag):
    """Delete a binding AND restore its original_text in place of {{tag}} in the doc."""
    proj = _proj(name)
    if tag not in proj.bindings:
        return jsonify({"error": "no such binding"}), 404
    b = proj.bindings[tag]
    doc = proj.read_doc()
    # Replace all occurrences of {{tag}} with the original text
    pattern = re.compile(r"\{\{\s*" + re.escape(tag) + r"\s*\}\}")
    new_doc = pattern.sub(b.original_text, doc)
    proj.write_doc(new_doc)
    proj.remove_binding(tag)
    return jsonify(_project_state(proj))


# --------------------------------------------------------------- routes: externals

@app.route("/api/projects/<name>/external", methods=["POST"])
def upload_external(name):
    proj = _proj(name)
    out = []
    for f in request.files.getlist("files"):
        if not f.filename:
            continue
        (proj.external_dir / f.filename).write_bytes(f.read())
        out.append(f.filename)
    state = _project_state(proj)
    state["uploaded"] = out
    return jsonify(state)


@app.route("/api/projects/<name>/external/<fname>/preview", methods=["GET"])
def preview_external(name, fname):
    """Return columns + a few rows so the binding panel can show 'pick a column'."""
    proj = _proj(name)
    path = proj.external_dir / fname
    if not path.exists():
        return jsonify({"error": "not found"}), 404
    suffix = path.suffix.lower()
    try:
        if suffix in (".csv", ".tsv"):
            df = pd.read_csv(path, sep="," if suffix == ".csv" else "\t", nrows=20)
        elif suffix in (".xlsx", ".xls"):
            df = pd.read_excel(path, nrows=20)
        else:
            return jsonify({"kind": "text", "preview": path.read_text(encoding="utf-8", errors="replace")[:2000]})
        return jsonify({
            "kind": "table",
            "columns": list(df.columns.astype(str)),
            "rows": df.head(10).astype(str).values.tolist(),
            "row_count_preview": len(df),
        })
    except Exception as e:
        return jsonify({"error": str(e)}), 500


# --------------------------------------------------------------- routes: render

@app.route("/api/projects/<name>/render", methods=["POST"])
def do_render(name):
    proj = _proj(name)
    allow_errors = bool((request.json or {}).get("allow_errors", False))
    out_path = proj.root / "output.docx"
    try:
        result = render(proj, out_path, allow_errors=allow_errors)
    except Exception as e:
        return jsonify({"error": str(e)}), 400
    return jsonify({
        "ok": True,
        "size": out_path.stat().st_size,
        "errors": [{"binding": e.binding, "message": e.message} for e in result.errors],
        "unresolved_tags": result.unresolved_tags,
    })


@app.route("/api/projects/<name>/download", methods=["GET"])
def download(name):
    proj = _proj(name)
    out_path = proj.root / "output.docx"
    if not out_path.exists():
        return jsonify({"error": "render first"}), 404
    return send_file(out_path, as_attachment=True,
                     download_name=f"{name}.docx",
                     mimetype="application/vnd.openxmlformats-officedocument.wordprocessingml.document")


@app.route("/api/projects/<name>/template", methods=["POST"])
def upload_template(name):
    proj = _proj(name)
    f = request.files.get("template")
    if not f:
        return jsonify({"error": "no file"}), 400
    proj.template_path.write_bytes(f.read())
    return jsonify(_project_state(proj))


# --------------------------------------------------------------- main

def run(cfg=None):
    cfg = {"host": "127.0.0.1", "port": 5050, "debug": False, **(cfg or {})}
    app.run(host=cfg["host"], port=cfg["port"], debug=cfg["debug"])


if __name__ == "__main__":
    run()
