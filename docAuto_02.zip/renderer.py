"""
Renderer: markdown + bindings -> styled .docx

Pipeline:
  1. Read doc.md
  2. Resolve bindings -> values dict
  3. Substitute {{tag}} placeholders with values (jinja2 — supports {% if %}, {% for %})
  4. Pandoc the substituted markdown -> .docx, using template.docx as reference

Validation gate: by default, refuse to render if any binding errors. Override
with allow_errors=True to render anyway (errors appear inline as ⚠️ markers).
"""

from dataclasses import dataclass
from pathlib import Path
import re

import jinja2
import pypandoc

from project import Project
from resolver import resolve_bindings, ResolutionError


_DEFAULTS = {
    "project_root": "/home/claude/mdproj/projects/imported",
    "output_path": "/home/claude/mdproj/projects/imported/output.docx",
    "allow_errors": False,
    "pandoc_format": "gfm+pipe_tables",
}


@dataclass
class RenderResult:
    output_path: Path
    used_bindings: list[str]
    unresolved_tags: list[str]
    errors: list[ResolutionError]


_TAG_RE = re.compile(r"\{\{\s*([a-zA-Z_][a-zA-Z0-9_.]*)\s*\}\}")
_LOOP_VAR_RE = re.compile(r"\{%\s*for\s+([a-zA-Z_][a-zA-Z0-9_]*)\s+in\s+")


def _find_tags(markdown: str) -> set[str]:
    return set(_TAG_RE.findall(markdown))


def _find_loop_vars(markdown: str) -> set[str]:
    return set(_LOOP_VAR_RE.findall(markdown))


def _substitute(markdown: str, values: dict) -> str:
    """Use jinja2 so we get {% if %} / {% for %} for free, plus dotted access."""
    env = jinja2.Environment(
        variable_start_string="{{",
        variable_end_string="}}",
        block_start_string="{%",
        block_end_string="%}",
        undefined=jinja2.ChainableUndefined,  # missing vars render as empty string
        autoescape=False,
    )
    return env.from_string(markdown).render(**values)


def render(proj: Project, output_path: Path, *,
           allow_errors: bool = False,
           pandoc_format: str = "gfm+pipe_tables") -> RenderResult:
    md = proj.read_doc()
    tags_in_doc = _find_tags(md)
    loop_vars = _find_loop_vars(md)

    values, errors = resolve_bindings(proj)
    bound_names = set(values.keys())

    # Tags in the doc that have no binding (treat root of dotted name)
    # Exclude jinja loop variables — they're not bindings, they're locals.
    unresolved = sorted(
        t for t in tags_in_doc
        if t.split(".")[0] not in bound_names
        and t.split(".")[0] not in loop_vars
    )

    if errors and not allow_errors:
        raise RuntimeError(
            f"Refusing to render: {len(errors)} binding error(s). "
            f"Pass allow_errors=True to render with inline markers. "
            f"First error: {errors[0].binding}: {errors[0].message}"
        )

    substituted = _substitute(md, values)

    # Pandoc via pypandoc_binary (bundled, no system install needed)
    extra = []
    if proj.template_path.exists():
        extra.append(f"--reference-doc={proj.template_path}")
    try:
        pypandoc.convert_text(
            substituted,
            "docx",
            format=pandoc_format,
            outputfile=str(output_path),
            extra_args=extra,
        )
    except Exception as e:
        raise RuntimeError(f"pandoc conversion failed: {e}")

    return RenderResult(
        output_path=Path(output_path),
        used_bindings=sorted(bound_names & {t.split(".")[0] for t in tags_in_doc}),
        unresolved_tags=unresolved,
        errors=errors,
    )


# ---------- end-to-end smoke test ----------

def _seed_full_project() -> Project:
    """Build a project from the imported skeleton + bindings to render every tag."""
    import pandas as pd
    from project import Project, Binding
    from word_import import import_docx

    src = Path("/home/claude/corporate_skeleton_template.docx")
    root = Path("/home/claude/mdproj/projects/_e2e")
    if root.exists():
        import shutil; shutil.rmtree(root)
    proj, _ = import_docx(src, root, "gfm+pipe_tables+raw_html")

    # External CSV for stat-driven bindings
    pd.DataFrame({
        "metric_name": ["Gross Margin", "EBITDA Margin", "Working Capital Days", "Free Cash Flow"],
        "value": ["42.1%", "18.4%", "47", "$2.6M"],
        "passed_review": ["YES", "YES", "NO", "YES"],
    }).to_csv(proj.external_dir / "metrics.csv", index=False)

    proj.bindings = {
        "project_name": Binding(name="project_name", kind="literal",
                                spec={"value": "Project Helios"}),
        "client_name": Binding(name="client_name", kind="literal",
                               spec={"value": "Acme Industrial"}),
        "prepared_by": Binding(name="prepared_by", kind="literal",
                               spec={"value": "C. Lopez"}),
        "report_date": Binding(name="report_date", kind="literal",
                               spec={"value": "2026-05-08"}),
        "executive_summary": Binding(name="executive_summary", kind="literal",
                                     spec={"value": "Helios delivers a 3-year payback."}),
        "project_background": Binding(name="project_background", kind="literal",
                                      spec={"value": "Acme commissioned this evaluation in Q1."}),
        "project_objectives": Binding(name="project_objectives", kind="literal",
                                      spec={"value": "Reduce per-unit cost by 15%."}),

        # Nested-style: jinja handles `financials.roi` if `financials` is a dict.
        # We'll use a literal dict via a small extension below.
        "financials": Binding(name="financials", kind="literal",
                              spec={"value": {"roi": "27.3%", "npv": "$3.1M", "irr": "19.8%"}}),

        # Stat-from-file
        "passed_pct": Binding(name="passed_pct", kind="expression",
                              source="metrics.csv",
                              spec={"expr": "percent(count_where(col='passed_review', value='YES'), row_count())"}),

        "operational_findings": Binding(name="operational_findings", kind="literal",
                                        spec={"value": "Bottleneck on packaging line 3."}),
        "risk_assessment": Binding(name="risk_assessment", kind="literal",
                                   spec={"value": "Resin supplier concentration."}),
        "conclusions": Binding(name="conclusions", kind="literal",
                               spec={"value": "Project meets hurdle criteria."}),
        "recommendations": Binding(name="recommendations", kind="literal",
                                   spec={"value": "Proceed to Phase 2."}),

        # Table from file
        "metrics_table": Binding(name="metrics_table", kind="file_table",
                                 source="metrics.csv",
                                 spec={"columns": ["metric_name", "value"]}),

        "external_doc": Binding(name="external_doc", kind="literal",
                                spec={"value": "_(External source content goes here.)_"}),
    }
    proj.save()

    # Patch the imported markdown to use our binding names where the template
    # used different ones (the imported doc uses {{financials.roi}} etc., already fine).
    # We just need to adapt the loop and external_document tags.
    md = proj.read_doc()
    md = md.replace(
        "{% for row in tables.financial_metrics %}",
        "{% for row in metrics_rows %}"
    )
    # Add a stat line and an external doc tag substitution
    md = md.replace(
        "{{sections.external_document}}",
        "{{external_doc}}\n\n**Review pass rate:** {{passed_pct}}\n\n{{metrics_table}}"
    )
    # Loop variant — supply rows directly
    proj.write_doc(md)
    proj.bindings["metrics_rows"] = Binding(
        name="metrics_rows", kind="literal",
        spec={"value": [
            {"metric_name": "Gross Margin", "value": "42.1%"},
            {"metric_name": "EBITDA Margin", "value": "18.4%"},
            {"metric_name": "Working Capital Days", "value": "47"},
            {"metric_name": "Free Cash Flow", "value": "$2.6M"},
        ]},
    )
    proj.save()
    return proj


def run(cfg=None):
    cfg = {**_DEFAULTS, **(cfg or {})}
    proj = _seed_full_project()
    out = Path(cfg["project_root"]).parent / "_e2e" / "output.docx"
    result = render(proj, out, allow_errors=cfg["allow_errors"])
    print(f"Rendered -> {result.output_path}")
    print(f"  size: {result.output_path.stat().st_size} bytes")
    print(f"  used bindings: {result.used_bindings}")
    print(f"  unresolved tags: {result.unresolved_tags}")
    print(f"  errors: {len(result.errors)}")


if __name__ == "__main__":
    run()
