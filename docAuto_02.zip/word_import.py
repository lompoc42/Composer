"""
Word importer: ports a .docx into a project as canonical markdown.

Strategy:
  1. Pre-scan the docx with python-docx to inventory things pandoc may flatten
     (text boxes, charts, headers/footers, equations, complex tables).
  2. Run pandoc with --extract-media to pull images out.
  3. Diff inventory vs. what made it into markdown -> import_report.json.

This is a one-time seed step. After import, the .docx is disposable.
"""

from dataclasses import dataclass, asdict
from pathlib import Path
import json
import zipfile
import re

import pypandoc
from docx import Document

from project import Project


_DEFAULTS = {
    "source_docx": "/home/claude/corporate_skeleton_template.docx",
    "project_root": "/home/claude/mdproj/projects/imported",
    "pandoc_format": "gfm+pipe_tables+raw_html",
}


@dataclass
class ImportReport:
    source_file: str
    paragraphs: int = 0
    tables: int = 0
    images: int = 0
    headers: int = 0
    footers: int = 0
    text_boxes: int = 0
    charts: int = 0
    equations: int = 0
    complex_tables: int = 0   # tables with merged cells
    notes: list = None

    def __post_init__(self):
        if self.notes is None:
            self.notes = []


def _scan_docx(path: Path) -> ImportReport:
    """Inventory the source doc using python-docx + raw zip inspection."""
    rpt = ImportReport(source_file=str(path))
    doc = Document(str(path))

    rpt.paragraphs = len(doc.paragraphs)
    rpt.tables = len(doc.tables)

    # Headers/footers
    for section in doc.sections:
        if section.header and any(p.text.strip() for p in section.header.paragraphs):
            rpt.headers += 1
        if section.footer and any(p.text.strip() for p in section.footer.paragraphs):
            rpt.footers += 1

    # Detect merged cells (heuristic: cell._tc appears more than once in a row)
    for tbl in doc.tables:
        seen = set()
        for row in tbl.rows:
            for cell in row.cells:
                tc_id = id(cell._tc)
                if tc_id in seen:
                    rpt.complex_tables += 1
                    break
                seen.add(tc_id)

    # Inspect raw XML for things python-docx hides
    with zipfile.ZipFile(path) as z:
        try:
            doc_xml = z.read("word/document.xml").decode("utf-8", errors="ignore")
        except KeyError:
            doc_xml = ""
        rpt.text_boxes = len(re.findall(r"<w:txbxContent\b", doc_xml))
        rpt.charts = len(re.findall(r"<c:chart\b|chart\.xml", doc_xml))
        rpt.equations = len(re.findall(r"<m:oMath\b", doc_xml))
        rpt.images = sum(1 for n in z.namelist() if n.startswith("word/media/"))

    return rpt


def _build_notes(rpt: ImportReport) -> list[str]:
    notes = []
    if rpt.text_boxes:
        notes.append(
            f"{rpt.text_boxes} text box(es) detected — likely flattened to plain "
            "paragraphs or dropped. Review output."
        )
    if rpt.charts:
        notes.append(
            f"{rpt.charts} chart(s) detected — extracted as static images, not "
            "live data. Re-bind via expressions if you want them dynamic."
        )
    if rpt.equations:
        notes.append(
            f"{rpt.equations} equation(s) detected — may render as LaTeX or be "
            "lost depending on pandoc version. Verify."
        )
    if rpt.complex_tables:
        notes.append(
            f"{rpt.complex_tables} table(s) with merged cells — markdown tables "
            "don't support merges; structure simplified."
        )
    if rpt.headers or rpt.footers:
        notes.append(
            f"Headers/footers present ({rpt.headers} hdr, {rpt.footers} ftr) — "
            "not preserved in markdown. They'll come from the render template instead."
        )
    if not notes:
        notes.append("Clean import — no known fidelity issues detected.")
    return notes


def import_docx(source: Path, project_root: Path,
                pandoc_format: str,
                timeout_seconds: int = 300) -> tuple[Project, ImportReport]:
    source = Path(source)
    proj = Project.create(project_root)

    # 1. Scan
    report = _scan_docx(source)

    # 2. Convert with pandoc (bundled via pypandoc_binary), extracting media.
    # Direct subprocess so we can enforce a timeout — pypandoc has no timeout hook.
    import subprocess
    pandoc_exe = pypandoc.get_pandoc_path()
    cmd = [
        pandoc_exe,
        str(source),
        "-f", "docx",
        "-t", pandoc_format,
        "-o", str(proj.doc_path),
        f"--extract-media={proj.assets_dir}",
    ]
    try:
        result = subprocess.run(
            cmd,
            capture_output=True, text=True,
            timeout=timeout_seconds,
        )
    except subprocess.TimeoutExpired:
        raise RuntimeError(
            f"pandoc timed out after {timeout_seconds}s. "
            f"This document may have content pandoc can't process efficiently "
            f"(complex tables, embedded objects, etc.). Try splitting it."
        )
    if result.returncode != 0:
        raise RuntimeError(f"pandoc failed: {result.stderr[:500]}")
    if result.stderr:
        report.notes.append(f"pandoc warnings: {result.stderr.strip()[:300]}")

    # 3. Build human-readable notes & write report
    report.notes = _build_notes(report) + report.notes
    proj.import_report_path.write_text(json.dumps(asdict(report), indent=2))

    # 4. Stage source template as the initial render template (user can swap)
    import shutil
    shutil.copy(source, proj.template_path)

    return proj, report


def run(cfg=None):
    cfg = {**_DEFAULTS, **(cfg or {})}
    proj, rpt = import_docx(
        Path(cfg["source_docx"]),
        Path(cfg["project_root"]),
        cfg["pandoc_format"],
    )
    print(f"Imported -> {proj.root}")
    print(f"  doc.md: {proj.doc_path.stat().st_size} bytes")
    print(f"\nQuality report:")
    print(f"  paragraphs: {rpt.paragraphs}")
    print(f"  tables: {rpt.tables} (complex: {rpt.complex_tables})")
    print(f"  images: {rpt.images}")
    print(f"  headers/footers: {rpt.headers}/{rpt.footers}")
    print(f"  text_boxes: {rpt.text_boxes}, charts: {rpt.charts}, equations: {rpt.equations}")
    print(f"\nNotes:")
    for n in rpt.notes:
        print(f"  - {n}")
    print(f"\n--- doc.md preview ---")
    print(proj.read_doc()[:500])


if __name__ == "__main__":
    run()
