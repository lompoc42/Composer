"""
Streamlit GUI for the markdown-canonical document system.

Tabs:
  1. Project       — create new / open existing / import from .docx
  2. Edit          — edit doc.md inline; live preview (markdown -> HTML)
  3. Bindings      — add/edit/delete bindings; view resolution status
  4. External Files — upload CSVs/Excels/text files to project/external/
  5. Render        — pre-render validation + render button + download

Run: streamlit run gui.py
"""

from pathlib import Path
import json
import shutil

import pandas as pd
import streamlit as st

from project import Project, Binding
from importer import import_docx
from resolver import resolve_bindings, _REGISTRY as EXPR_FUNCS
from renderer import render, _find_tags, _find_loop_vars


PROJECTS_ROOT = Path("/home/claude/mdproj/projects")
PROJECTS_ROOT.mkdir(parents=True, exist_ok=True)


# ---------------------------------------------------------------- session

def _get_project() -> Project | None:
    root = st.session_state.get("project_root")
    return Project.load(Path(root)) if root else None


def _set_project(root: Path) -> None:
    st.session_state["project_root"] = str(root)


# ---------------------------------------------------------------- tabs

def tab_project():
    st.header("Project")
    proj = _get_project()
    if proj:
        st.success(f"Open: `{proj.root}`")
        st.write(f"**Doc:** {proj.doc_path.name} ({proj.doc_path.stat().st_size if proj.doc_path.exists() else 0} bytes)")
        st.write(f"**Bindings:** {len(proj.bindings)}")
        st.write(f"**External files:** {len(list(proj.external_dir.iterdir())) if proj.external_dir.exists() else 0}")
        if proj.import_report_path.exists():
            with st.expander("Import quality report"):
                st.json(json.loads(proj.import_report_path.read_text()))

    st.divider()
    st.subheader("Open existing")
    existing = sorted(p.name for p in PROJECTS_ROOT.iterdir() if p.is_dir() and not p.name.startswith("_"))
    if existing:
        choice = st.selectbox("Project", existing, key="open_choice")
        if st.button("Open", key="open_btn"):
            _set_project(PROJECTS_ROOT / choice)
            st.rerun()
    else:
        st.caption("No projects yet.")

    st.divider()
    st.subheader("Create new")
    new_name = st.text_input("Name", key="new_name")
    if st.button("Create blank project", key="create_btn") and new_name:
        p = Project.create(PROJECTS_ROOT / new_name)
        _set_project(p.root)
        st.rerun()

    st.divider()
    st.subheader("Import from Word")
    import_name = st.text_input("New project name", key="import_name")
    uploaded = st.file_uploader("Source .docx", type=["docx"], key="import_upload")
    if st.button("Import", key="import_btn") and uploaded and import_name:
        target = PROJECTS_ROOT / import_name
        tmp = PROJECTS_ROOT / f"_tmp_{import_name}.docx"
        tmp.write_bytes(uploaded.getbuffer())
        proj, rpt = import_docx(tmp, target, "gfm+pipe_tables+raw_html")
        tmp.unlink()
        _set_project(proj.root)
        st.success("Imported.")
        st.json({k: v for k, v in rpt.__dict__.items() if k != "notes"})
        st.write("**Notes:**")
        for n in rpt.notes:
            st.write(f"- {n}")
        st.rerun()


def tab_edit():
    st.header("Edit")
    proj = _get_project()
    if not proj:
        st.info("Open or create a project first.")
        return

    text = st.text_area("doc.md", value=proj.read_doc(), height=400, key="doc_editor")
    col1, col2 = st.columns([1, 4])
    with col1:
        if st.button("Save", key="save_doc"):
            proj.write_doc(text)
            st.success("Saved.")
    with col2:
        tags = sorted(_find_tags(text))
        loops = sorted(_find_loop_vars(text))
        st.caption(f"Tags found: {len(tags)} · Loop vars: {len(loops)}")

    with st.expander("Live preview (substituted markdown → HTML)"):
        try:
            from renderer import _substitute
            values, errors = resolve_bindings(proj)
            preview_md = _substitute(text, values)
            st.markdown(preview_md)
            if errors:
                st.warning(f"{len(errors)} binding error(s) — see Render tab")
        except Exception as e:
            st.error(f"Preview failed: {e}")


def tab_bindings():
    st.header("Bindings")
    proj = _get_project()
    if not proj:
        st.info("Open or create a project first.")
        return

    # Pre-resolve to show status next to each binding
    values, errors = resolve_bindings(proj)
    error_map = {e.binding: e.message for e in errors}

    # Tags found in doc but not bound
    md = proj.read_doc()
    tags = _find_tags(md)
    loops = _find_loop_vars(md)
    bound = set(proj.bindings.keys())
    missing = sorted(t.split(".")[0] for t in tags
                     if t.split(".")[0] not in bound
                     and t.split(".")[0] not in loops)
    if missing:
        st.warning(f"Tags in doc with no binding: {', '.join(set(missing))}")

    st.subheader("Existing")
    if not proj.bindings:
        st.caption("No bindings yet.")
    for name, b in list(proj.bindings.items()):
        with st.expander(f"`{{{{{name}}}}}` — {b.kind}"
                         + (" ⚠️" if name in error_map else "")):
            st.write(f"**Description:** {b.description or '_none_'}")
            st.write(f"**Source:** `{b.source or '_none_'}`")
            st.write(f"**Spec:** `{b.spec}`")
            if name in error_map:
                st.error(error_map[name])
            else:
                st.success(f"Resolves to: `{str(values.get(name))[:100]}`")
            if st.button(f"Delete `{name}`", key=f"del_{name}"):
                proj.remove_binding(name)
                st.rerun()

    st.divider()
    st.subheader("Add binding")
    name = st.text_input("Tag name", key="bind_name", help="Used as `{{name}}` in markdown")
    kind = st.selectbox("Kind", ["literal", "file_text", "file_table", "expression"], key="bind_kind")
    desc = st.text_input("Description (optional)", key="bind_desc")

    spec: dict = {}
    source = None

    if kind == "literal":
        val = st.text_area("Value", key="bind_lit_val")
        spec = {"value": val}

    elif kind in ("file_text", "file_table", "expression"):
        ext_files = sorted(p.name for p in proj.external_dir.iterdir() if p.is_file()) if proj.external_dir.exists() else []
        if not ext_files:
            st.caption("Upload an external file first (External Files tab).")
        else:
            source = st.selectbox("External file", ext_files, key=f"bind_src_{kind}")

        if kind == "file_table":
            cols_str = st.text_input("Columns (comma-sep, blank=all)", key="bind_tbl_cols")
            max_rows = st.number_input("Max rows (0=all)", min_value=0, value=0, key="bind_tbl_max")
            sheet = st.text_input("Sheet (Excel only)", key="bind_tbl_sheet")
            spec = {}
            if cols_str:
                spec["columns"] = [c.strip() for c in cols_str.split(",")]
            if max_rows:
                spec["max_rows"] = int(max_rows)
            if sheet:
                spec["sheet"] = sheet

        if kind == "expression":
            with st.expander("Available functions"):
                for fn_name in sorted(EXPR_FUNCS):
                    st.code(fn_name, language=None)
            expr = st.text_input(
                "Expression",
                key="bind_expr",
                placeholder="percent(count_where(col='Status', value='YES'), row_count())",
            )
            sheet = st.text_input("Sheet (Excel only)", key="bind_expr_sheet")
            spec = {"expr": expr}
            if sheet:
                spec["sheet"] = sheet

    if st.button("Add binding", key="bind_add") and name:
        proj.set_binding(Binding(name=name, kind=kind, source=source,
                                 spec=spec, description=desc))
        st.success(f"Added `{name}`")
        st.rerun()


def tab_external():
    st.header("External Files")
    proj = _get_project()
    if not proj:
        st.info("Open or create a project first.")
        return

    uploaded = st.file_uploader("Add file", key="ext_upload",
                                accept_multiple_files=True,
                                type=["csv", "tsv", "xlsx", "xls", "txt", "md"])
    if uploaded:
        for u in uploaded:
            (proj.external_dir / u.name).write_bytes(u.getbuffer())
        st.success(f"Uploaded {len(uploaded)} file(s)")
        st.rerun()

    st.subheader("Files in project")
    files = sorted(proj.external_dir.iterdir()) if proj.external_dir.exists() else []
    if not files:
        st.caption("None yet.")
    for f in files:
        c1, c2, c3 = st.columns([4, 1, 1])
        c1.write(f"`{f.name}` ({f.stat().st_size} bytes)")
        if c2.button("Preview", key=f"prev_{f.name}"):
            try:
                if f.suffix.lower() in (".csv", ".tsv"):
                    st.dataframe(pd.read_csv(f, sep="," if f.suffix == ".csv" else "\t").head(20))
                elif f.suffix.lower() in (".xlsx", ".xls"):
                    st.dataframe(pd.read_excel(f).head(20))
                else:
                    st.code(f.read_text()[:2000])
            except Exception as e:
                st.error(str(e))
        if c3.button("Delete", key=f"del_ext_{f.name}"):
            f.unlink()
            st.rerun()


def tab_render():
    st.header("Render")
    proj = _get_project()
    if not proj:
        st.info("Open or create a project first.")
        return

    # Validation summary
    md = proj.read_doc()
    tags = _find_tags(md)
    loops = _find_loop_vars(md)
    bound = set(proj.bindings.keys())
    missing = sorted(set(t.split(".")[0] for t in tags
                         if t.split(".")[0] not in bound
                         and t.split(".")[0] not in loops))
    values, errors = resolve_bindings(proj)

    c1, c2, c3 = st.columns(3)
    c1.metric("Tags in doc", len(tags))
    c2.metric("Unresolved", len(missing))
    c3.metric("Errors", len(errors))

    if missing:
        st.warning(f"Unresolved tags: {', '.join(missing)}")
    if errors:
        st.error("Binding errors:")
        for e in errors:
            st.write(f"- `{e.binding}`: {e.message}")

    st.divider()
    if not proj.template_path.exists():
        st.info("No reference template (template.docx) — pandoc will use its default styling.")
    upload_tpl = st.file_uploader("Replace reference template", type=["docx"], key="tpl_upload")
    if upload_tpl:
        proj.template_path.write_bytes(upload_tpl.getbuffer())
        st.success("Template updated.")
        st.rerun()

    allow_errors = st.checkbox("Render anyway if errors present (inline ⚠️ markers)",
                               value=False, key="allow_err")
    if st.button("Render", key="render_btn", type="primary"):
        out_path = proj.root / "output.docx"
        try:
            result = render(proj, out_path, allow_errors=allow_errors)
            st.success(f"Rendered → `{result.output_path.name}` "
                       f"({result.output_path.stat().st_size} bytes)")
            st.download_button("Download .docx",
                               data=out_path.read_bytes(),
                               file_name=f"{proj.root.name}.docx",
                               key="dl_btn")
        except Exception as e:
            st.error(str(e))


# ---------------------------------------------------------------- main

def main():
    st.set_page_config(page_title="MD Doc Composer", layout="wide")
    st.title("Markdown Document Composer")

    proj = _get_project()
    st.sidebar.write(f"**Current project:**")
    st.sidebar.code(proj.root.name if proj else "(none)")
    if proj and st.sidebar.button("Close project"):
        st.session_state.pop("project_root", None)
        st.rerun()

    tabs = st.tabs(["Project", "Edit", "Bindings", "External Files", "Render"])
    with tabs[0]: tab_project()
    with tabs[1]: tab_edit()
    with tabs[2]: tab_bindings()
    with tabs[3]: tab_external()
    with tabs[4]: tab_render()


if __name__ == "__main__":
    main()
