@echo off
cd /d "%~dp0"

if not exist ".venv\Scripts\python.exe" (
    echo ERROR: virtual environment not found. Run setup.bat first.
    pause
    exit /b 1
)

echo Starting MD Doc Composer...
echo (Opening browser at http://localhost:5050)
echo (Close this window to stop the server.)
echo.
start "" "http://localhost:5050"
".venv\Scripts\python.exe" app.py
