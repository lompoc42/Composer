"""
Bedrock test: render the skeleton template with sample data.
Goal: see exactly what docxtpl does with each variable type in the template,
including the trickiest one — sections.external_document (rich content injection).
"""

from docxtpl import DocxTemplate, RichText
from pathlib import Path

CONFIG = {
    "template_path": "/home/claude/corporate_skeleton_template.docx",
    "output_path": "/home/claude/rendered_test.docx",
}

def build_context(tpl: DocxTemplate) -> dict:
    # --- Rich content for the "external document" injection point ---
    # This is the part the outline hand-waves. Demonstrating two options:
    #   (1) RichText: inline formatted runs (single paragraph).
    #   (2) Subdoc: full multi-paragraph + table fragments.
    sd = tpl.new_subdoc()
    sd.add_paragraph(
        "This block was injected from an external source. "
        "It supports multiple paragraphs, headings, and tables."
    )
    sd.add_heading("Excerpt: Q3 Performance", level=2)
    p = sd.add_paragraph("Margin expanded to ")
    p.add_run("18.4%").bold = True
    p.add_run(" driven by SKU rationalization in the East region.")

    table = sd.add_table(rows=3, cols=2)
    table.style = "Light Grid Accent 1"
    table.cell(0, 0).text = "Metric"
    table.cell(0, 1).text = "Value"
    table.cell(1, 0).text = "Revenue YoY"
    table.cell(1, 1).text = "+12.1%"
    table.cell(2, 0).text = "OpEx YoY"
    table.cell(2, 1).text = "-3.4%"

    return {
        # Scalars
        "project_name": "Project Helios",
        "client_name": "Acme Industrial",
        "prepared_by": "C. Lopez",
        "report_date": "2026-05-04",

        # Long text blocks
        "executive_summary": (
            "Helios delivers a 3-year payback on a $4.2M capex with sustained "
            "margin uplift across two of three operating regions."
        ),
        "project_background": "Acme commissioned an evaluation of the Helios initiative "
                              "following the Q1 board mandate to reduce unit cost.",
        "project_objectives": "Reduce per-unit cost by 15%, expand throughput by 20%, "
                              "and achieve breakeven within 36 months.",

        # Nested object (dot access in template)
        "financials": {
            "roi": "27.3%",
            "npv": "$3.1M",
            "irr": "19.8%",
        },

        # Loop input
        "tables": {
            "financial_metrics": [
                {"metric_name": "Gross Margin", "value": "42.1%"},
                {"metric_name": "EBITDA Margin", "value": "18.4%"},
                {"metric_name": "Working Capital Days", "value": "47"},
                {"metric_name": "Free Cash Flow", "value": "$2.6M"},
            ],
        },

        "operational_findings": "Throughput bottleneck localized to packaging line 3.",
        "risk_assessment": "Primary risk: supplier concentration on resin feedstock.",

        # Rich-content injection point
        "sections": {
            "external_document": sd,
        },

        "conclusions": "Project meets all hurdle criteria.",
        "recommendations": "Proceed to Phase 2 with a staged capital release.",
    }


def main():
    tpl = DocxTemplate(CONFIG["template_path"])
    ctx = build_context(tpl)

    # What variables does the template actually expose?
    declared = tpl.get_undeclared_template_variables()
    print(f"Template-declared top-level vars: {sorted(declared)}")

    tpl.render(ctx)
    tpl.save(CONFIG["output_path"])
    print(f"Rendered -> {CONFIG['output_path']}")
    print(f"File size: {Path(CONFIG['output_path']).stat().st_size} bytes")


if __name__ == "__main__":
    main()
