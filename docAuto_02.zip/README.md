# MD Doc Composer

A document composition tool that uses canonical markdown + bindings to external
data, with a single-page UI for highlight-to-bind editing.

## Run

**Mac (first time):** open Terminal, `cd` to this folder, run `bash setup.command`
once. After that, double-click `setup.command` and `start.command` work normally.

**Windows:** double-click `setup.bat` once, then `start.bat`.

The app opens in your browser at `http://localhost:5050`. Close the terminal
window to stop.

## Workflow

1. **Open a project** — pick existing, create blank, or import a Word doc.
2. **Edit** — type / paste / clean up the markdown.
3. **Bind** — highlight text, click the floating "+ bind selection" button.
   - **Literal** — replace selection with a fixed value
   - **File text** — pull text from an uploaded file
   - **File table** — render a CSV/Excel as a markdown table
   - **Expression** — compute a stat (count, percent, sum, etc.) from a CSV/Excel
4. **Edit / delete bindings** — click any pill in the editor to open its panel.
   Deleting a binding restores the original highlighted text.
5. **Render** — top-bar button. Generates a styled `.docx` and downloads it.

## Pills

`{{tag}}` patterns in the markdown render as colored pills showing the
resolved value live. Errors render red. Click any pill to edit or delete.

## Reference template

The "load template" button accepts a `.docx` whose styles drive the rendered
output (headings, fonts, spacing). Pandoc uses it as a `--reference-doc`.

## Files

| File | Role |
|---|---|
| `app.py` | Flask backend + JSON API |
| `index.html` | Single-page UI (CodeMirror 6) |
| `project.py` | Project structure, bindings schema |
| `importer.py` | Word → markdown port + quality report |
| `resolver.py` | Bindings + external files → resolved values |
| `renderer.py` | Substitute tags → pandoc → styled .docx |
| `setup.command` / `setup.bat` | Install Python deps |
| `start.command` / `start.bat` | Launch app |

## Network requirement

The first page load fetches CodeMirror 6 from `esm.sh`. If your machine can
reach the internet from a browser, this works without further setup. If your
corporate network blocks `esm.sh`, the editor won't load — let me know and
I'll bundle the JS locally.

## Expression functions

- `row_count()`, `col_count()`
- `count_where(col=, value=)`
- `sum_col(col=)`, `mean_col(col=)`, `min_col(col=)`, `max_col(col=)`
- `percent(num, denom, decimals=1)`, `round_to(value, decimals=0)`

Add new ones in `resolver.py` (`ExprFunctions` class). Prefix with `_df_` for
functions that need the DataFrame as first arg.
