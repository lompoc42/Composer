#!/bin/bash
cd "$(dirname "$0")"

if [ ! -x "./.venv/bin/python" ]; then
    echo "ERROR: virtual environment not found. Run setup.command first."
    read -n 1
    exit 1
fi

echo "Starting MD Doc Composer..."
echo "(Opening browser at http://localhost:5050)"
echo "(Close this window to stop the server.)"
echo
(sleep 1 && open "http://localhost:5050") &
./.venv/bin/python app.py
