@echo off
cd /d "%~dp0"
echo === MD Doc Composer - Setup ===
echo.

REM 1. Python check
where python >nul 2>&1
if errorlevel 1 (
    echo ERROR: python not found. Install from https://www.python.org/downloads/
    echo Make sure to check "Add Python to PATH" during install.
    pause
    exit /b 1
)
for /f "tokens=*" %%v in ('python --version') do echo Python: %%v

REM 2. Create venv inside this folder (portable; delete .venv to reset)
if not exist ".venv" (
    echo.
    echo Creating virtual environment in .venv ...
    python -m venv .venv
    if errorlevel 1 (
        echo ERROR: venv creation failed.
        pause
        exit /b 1
    )
)
echo venv: .\.venv

REM 3. Install Python packages into the venv
echo.
echo Installing Python packages into .venv ...
call ".venv\Scripts\python.exe" -m pip install --quiet --upgrade pip
call ".venv\Scripts\python.exe" -m pip install --quiet flask docxtpl docxcompose pandas openpyxl tabulate jinja2 python-docx pypandoc_binary
if errorlevel 1 (
    echo ERROR: pip install failed.
    pause
    exit /b 1
)

echo.
echo Setup complete. Double-click start.bat to launch.
pause
