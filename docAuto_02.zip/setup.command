#!/bin/bash
cd "$(dirname "$0")"
set -e

echo "=== MD Doc Composer — Setup ==="
echo

# 1. Python check
if ! command -v python3 &> /dev/null; then
    echo "ERROR: python3 not found. Install from https://www.python.org/downloads/"
    exit 1
fi
echo "✓ Python: $(python3 --version)"

# 2. Create venv inside this folder (portable; rm -rf .venv to reset)
if [ ! -d ".venv" ]; then
    echo
    echo "Creating virtual environment in .venv ..."
    python3 -m venv .venv
fi
echo "✓ venv: ./.venv"

# 3. Install Python packages into the venv
echo
echo "Installing Python packages into .venv ..."
./.venv/bin/python -m pip install --quiet --upgrade pip
./.venv/bin/python -m pip install --quiet \
    flask \
    docxtpl \
    docxcompose \
    pandas \
    openpyxl \
    tabulate \
    jinja2 \
    python-docx \
    pypandoc_binary

# 4. Make start script executable
chmod +x "$(dirname "$0")/start.command" 2>/dev/null || true

echo
echo "✓ Setup complete. Double-click start.command to launch."
echo "(Press any key to close this window.)"
read -n 1
