#!/bin/bash
# start.command — macOS launcher. Activates .venv and runs the Flask app,
# then opens the default browser to the local URL.

cd "$(dirname "$0")" || exit 1

if [ ! -d ".venv" ]; then
    echo "ERROR: .venv not found. Run prep.command first."
    echo "Press any key to close..."
    read -n 1 -s
    exit 1
fi

# shellcheck source=/dev/null
source .venv/bin/activate

# Open the browser ~1.5 seconds after launch so Flask has time to bind.
( sleep 1.5 && open "http://127.0.0.1:5050" ) &

python app.py
