"""
Flask app for GUI 1 (Composer).

No argparse. Run with:  python app.py

Routes:
  GET  /                                      project list (recent + new + open)
  POST /api/pick_directory                    invoke native folder picker
  POST /projects                              create new project (parent + name + skeleton)
  POST /projects/open                         open an existing project folder
  GET  /projects/<name>                       project dashboard (tag list, statuses)
  POST /projects/<name>/rescan                re-scan skeleton, reconcile mappings
  GET  /projects/<name>/tags/<tag>            per-tag editor
  POST /projects/<name>/tags/<tag>            save a tag mapping (multipart for uploads)
  POST /projects/<name>/tags/<tag>/reset      clear a tag mapping (section reset)
  POST /projects/<name>/render                render <project>.docx
  GET  /projects/<name>/download              download <project>.docx
  GET  /projects/<name>/sources/<filename>    serve an uploaded source for preview
"""
from __future__ import annotations

import json
import subprocess
import sys
import traceback
from pathlib import Path

from flask import (
    Flask,
    abort,
    flash,
    jsonify,
    redirect,
    render_template,
    request,
    send_from_directory,
    url_for,
)

import adapters
from adapters.base import AdapterError
from config import (
    DEBUG,
    HOST,
    MAX_UPLOAD_BYTES,
    PORT,
    PROJECTS_DIR,
)
from project_io import (
    all_registered,
    init_project_at,
    load_project,
    open_existing,
    output_dir,
    project_exists,
    reconcile_with_skeleton,
    reset_tag,
    save_project,
    skeleton_path,
    sources_dir,
)
from renderer import render_project
from scanner import scan_skeleton
from utils import sanitize_filename


app = Flask(__name__)
app.config["MAX_CONTENT_LENGTH"] = MAX_UPLOAD_BYTES
app.secret_key = "gui1-composer-dev"  # dev only; replace if exposing beyond localhost


# ---------- helpers -----------------------------------------------------------

def _require_project(slug: str) -> str:
    if not project_exists(slug):
        abort(404, f"No such project: {slug}")
    return slug


def _save_upload(slug: str, file_storage) -> str:
    """Stash an uploaded file under sources/. Returns the saved basename."""
    raw = file_storage.filename or "upload"
    base = sanitize_filename(Path(raw).name)
    sdir = sources_dir(slug)
    sdir.mkdir(parents=True, exist_ok=True)
    file_storage.save(str(sdir / base))
    return base


def _maybe_save(field_name: str, slug: str):
    f = request.files.get(field_name)
    if f and f.filename:
        return _save_upload(slug, f)
    return None


def _run_directory_picker(title: str, initial_dir: str) -> dict:
    """Spawn a tkinter folder picker in a child process. Same pattern as the
    TurtleVision Pruner. Returns one of:
        {"ok": True, "path": "<abs>"}
        {"ok": False, "cancelled": True}
        {"ok": False, "error": "<msg>"}
    """
    try:
        ip = Path(initial_dir).expanduser()
        if not ip.is_dir():
            ip = Path.home()
    except Exception:
        ip = Path.home()

    picker_code = r'''
import json, sys, tkinter as tk
from tkinter import filedialog
title, initial_dir = sys.argv[1], sys.argv[2]
root = tk.Tk()
root.withdraw()
root.attributes("-topmost", True)
try:
    sel = filedialog.askdirectory(title=title, initialdir=initial_dir, mustexist=True)
    print(json.dumps({"selected": sel}))
finally:
    root.destroy()
'''
    try:
        proc = subprocess.run(
            [sys.executable, "-c", picker_code, title, str(ip)],
            capture_output=True, text=True, check=False,
        )
    except Exception as e:
        return {"ok": False, "error": f"Could not launch picker: {e}"}

    if proc.returncode != 0:
        msg = (proc.stderr or "").strip() or "picker failed"
        return {"ok": False, "error": msg}

    out = (proc.stdout or "").strip()
    if not out:
        return {"ok": False, "cancelled": True}
    try:
        data = json.loads(out)
    except json.JSONDecodeError as e:
        return {"ok": False, "error": f"Bad picker output: {e}"}

    sel = (data.get("selected") or "").strip()
    if not sel:
        return {"ok": False, "cancelled": True}
    return {"ok": True, "path": str(Path(sel).resolve())}


# ---------- routes ------------------------------------------------------------

@app.route("/")
def index():
    return render_template(
        "projects.html",
        projects=all_registered(),
        default_parent=str(PROJECTS_DIR.resolve()),
    )


@app.route("/api/pick_directory", methods=["POST"])
def api_pick_directory():
    payload = request.get_json(silent=True) or {}
    title = (payload.get("title") or "Select folder").strip() or "Select folder"
    initial_dir = (payload.get("initial_dir") or "").strip() or str(Path.home())
    result = _run_directory_picker(title, initial_dir)
    status = 200 if result.get("ok") or result.get("cancelled") else 500
    return jsonify(result), status


@app.route("/projects", methods=["POST"])
def create_project():
    name = request.form.get("name", "").strip()
    parent_raw = request.form.get("parent_path", "").strip()

    if not name:
        flash("Project name is required.")
        return redirect(url_for("index"))
    if not parent_raw:
        flash("Location (parent folder) is required.")
        return redirect(url_for("index"))

    parent = Path(parent_raw).expanduser()
    try:
        parent = parent.resolve()
    except Exception as e:
        flash(f"Could not resolve parent path: {e}")
        return redirect(url_for("index"))
    if not parent.is_dir():
        flash(f"Parent folder does not exist: {parent}")
        return redirect(url_for("index"))

    safe = sanitize_filename(name)
    project_root = (parent / safe).resolve()
    if (project_root / "project.json").exists():
        flash(
            f"A project already exists at {project_root}. Use 'Open existing project' to load it."
        )
        return redirect(url_for("index"))

    sk_file = request.files.get("skeleton")
    if not sk_file or not sk_file.filename:
        flash("Skeleton .docx is required.")
        return redirect(url_for("index"))
    if not sk_file.filename.lower().endswith(".docx"):
        flash("Skeleton must be a .docx file.")
        return redirect(url_for("index"))

    project_root.mkdir(parents=True, exist_ok=True)
    sk_path = project_root / "skeleton.docx"
    sk_file.save(str(sk_path))

    catalog = scan_skeleton(sk_path)
    slug, root = init_project_at(parent, name, catalog)
    flash(f"Created '{slug}' at {root} with {len(catalog['scalars'])} tag(s).")
    return redirect(url_for("dashboard", name=slug))


@app.route("/projects/open", methods=["POST"])
def open_project():
    raw = request.form.get("path", "").strip()
    if not raw:
        flash("No folder selected.")
        return redirect(url_for("index"))
    try:
        slug = open_existing(Path(raw))
    except FileNotFoundError as e:
        flash(str(e))
        return redirect(url_for("index"))
    flash(f"Opened '{slug}'.")
    return redirect(url_for("dashboard", name=slug))


@app.route("/projects/<name>")
def dashboard(name):
    slug = _require_project(name)
    state = load_project(slug)
    return render_template(
        "dashboard.html",
        project=state,
        project_path=str(skeleton_path(slug).parent),
    )


@app.route("/projects/<name>/rescan", methods=["POST"])
def rescan(name):
    slug = _require_project(name)
    sk = skeleton_path(slug)
    if not sk.exists():
        flash("Skeleton file is missing on disk.")
        return redirect(url_for("dashboard", name=slug))
    catalog = scan_skeleton(sk)
    state = reconcile_with_skeleton(slug, catalog)
    removed = state.get("last_removed_tags", [])
    msg = f"Rescanned: {len(catalog['scalars'])} tag(s)."
    if removed:
        msg += f" Removed tags with prior mappings: {', '.join(removed)}."
    flash(msg)
    return redirect(url_for("dashboard", name=slug))


@app.route("/projects/<name>/tags/<path:tag>", methods=["GET", "POST"])
def edit_tag(name, tag):
    slug = _require_project(name)
    state = load_project(slug)
    if tag not in state["mappings"]:
        abort(404, f"Unknown tag: {tag}")
    mapping = state["mappings"][tag]
    kind = mapping["kind"]

    if request.method == "POST":
        source_type = request.form.get("source_type") or None
        if source_type is None:
            mapping["source_type"] = None
            mapping["config"] = {}
            save_project(slug, state)
            flash(f"Cleared {tag}.")
            return redirect(url_for("edit_tag", name=slug, tag=tag))

        config: dict = {}
        try:
            if source_type == "text":
                config["value"] = request.form.get("value", "")
                config["rich"] = bool(request.form.get("rich"))
            elif source_type == "docx_import":
                fn = _maybe_save("file", slug)
                config["filename"] = fn or mapping.get("config", {}).get("filename")
            elif source_type == "image":
                fn = _maybe_save("file", slug)
                config["filename"] = fn or mapping.get("config", {}).get("filename")
                w = request.form.get("width_in", "4.0").strip()
                config["width_in"] = float(w) if w else 4.0
            else:
                raise AdapterError(f"Unknown source type: {source_type}")

            adapter_cls = adapters.get(source_type)
            adapter_cls.validate(config)
        except (AdapterError, ValueError) as e:
            flash(f"Could not save: {e}")
            return redirect(url_for("edit_tag", name=slug, tag=tag))

        mapping["source_type"] = source_type
        mapping["config"] = config
        save_project(slug, state)
        flash(f"Saved mapping for {tag}.")
        return redirect(url_for("dashboard", name=slug))

    available = adapters.available_for_kind(kind)
    return render_template(
        "edit_tag.html",
        project=state,
        tag=tag,
        mapping=mapping,
        kind=kind,
        available=available,
    )


@app.route("/projects/<name>/tags/<path:tag>/reset", methods=["POST"])
def tag_reset(name, tag):
    slug = _require_project(name)
    try:
        reset_tag(slug, tag)
        flash(f"Reset {tag}.")
    except KeyError:
        abort(404)
    return redirect(url_for("dashboard", name=slug))


@app.route("/projects/<name>/render", methods=["POST"])
def do_render(name):
    slug = _require_project(name)
    try:
        result = render_project(slug)
    except PermissionError as e:
        flash(str(e))
        return redirect(url_for("dashboard", name=slug))
    except Exception as e:
        traceback.print_exc()
        flash(f"Render failed: {e}")
        return redirect(url_for("dashboard", name=slug))

    bits = [f"Rendered {result.output_path.name}."]
    if result.unmapped:
        bits.append(f"{len(result.unmapped)} tag(s) still unmapped: "
                    f"{', '.join(result.unmapped)}.")
    if result.warnings:
        bits.append("Warnings: " + " | ".join(result.warnings))
    if result.errors:
        bits.append("Errors: " + " | ".join(result.errors))
    flash(" ".join(bits))
    return redirect(url_for("dashboard", name=slug))


@app.route("/projects/<name>/download")
def download(name):
    slug = _require_project(name)
    state = load_project(slug)
    fname = f"{sanitize_filename(state.get('name') or slug)}.docx"
    return send_from_directory(str(output_dir(slug)), fname, as_attachment=True)


@app.route("/projects/<name>/sources/<path:filename>")
def serve_source(name, filename):
    """Serve a source file (used by the GUI to preview/check uploads)."""
    slug = _require_project(name)
    return send_from_directory(str(sources_dir(slug)), filename, as_attachment=False)


# ---------- entrypoint --------------------------------------------------------

if __name__ == "__main__":
    PROJECTS_DIR.mkdir(parents=True, exist_ok=True)
    print(f"GUI 1 Composer — http://{HOST}:{PORT}/")
    print(f"Default project root: {PROJECTS_DIR}")
    app.run(host=HOST, port=PORT, debug=DEBUG)
