"""
Smoke test for GUI 1 (simplified v2 — text / docx / image only).

Steps:
    1. Generate a clean test skeleton with three flat scalar tags.
    2. Create a project from it.
    3. Map each tag to one of: text, docx_import, image.
    4. Render the big doc.
    5. Verify substitutions made it in (XML walk, since Subdoc inserts aren't
       at the top-level paragraph collection).
    6. Test section reset.
"""
import shutil
import sys
from pathlib import Path

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE))

from docx import Document
from docx.shared import Inches
from PIL import Image, ImageDraw  # noqa: F401  -- imported for the dummy image

from scanner import scan_skeleton
from project_io import (
    init_project,
    load_project,
    save_project,
    project_dir,
    sources_dir,
    skeleton_path,
    reset_tag,
)
from renderer import render_project
from utils import safe_copy

PROJECT = "smoke_test"


def make_test_skeleton(out_path: Path) -> None:
    """Build a clean skeleton with three flat scalar tags."""
    doc = Document()
    doc.add_heading("Test Project Report", 0)
    doc.add_paragraph("Project: {{project_name}}")
    doc.add_heading("Summary", level=1)
    doc.add_paragraph("{{summary_section}}")
    doc.add_heading("Diagram", level=1)
    doc.add_paragraph("{{diagram}}")
    doc.save(str(out_path))


def make_test_subdoc(out_path: Path) -> None:
    """An external .docx that will be embedded via docx_import."""
    doc = Document()
    doc.add_heading("Embedded Summary", level=2)
    doc.add_paragraph(
        "This paragraph was authored elsewhere and dropped in via docx_import. "
        "Formatting is preserved natively.")
    doc.add_paragraph("A second paragraph follows in the same imported section.")
    doc.save(str(out_path))


def make_test_image(out_path: Path) -> None:
    """Tiny placeholder PNG so we exercise the image adapter end-to-end."""
    img = Image.new("RGB", (300, 120), (40, 60, 100))
    d = ImageDraw.Draw(img)
    d.text((10, 50), "diagram placeholder", fill=(220, 220, 220))
    img.save(str(out_path), "PNG")


def main() -> None:
    pdir = project_dir(PROJECT)
    if pdir.exists():
        shutil.rmtree(pdir)
    pdir.mkdir(parents=True)

    # 1. Skeleton
    sk = skeleton_path(PROJECT)
    make_test_skeleton(sk)

    # 2. Init project from catalog
    catalog = scan_skeleton(sk)
    print(f"Init: {len(catalog['scalars'])} scalar(s)")
    assert len(catalog["scalars"]) == 3

    init_project(PROJECT, catalog)

    # 3. Build sources
    sources_dir(PROJECT).mkdir(exist_ok=True)
    sub_path = sources_dir(PROJECT) / "embedded.docx"
    img_path = sources_dir(PROJECT) / "diagram.png"
    make_test_subdoc(sub_path)
    make_test_image(img_path)

    # 4. Set mappings: text / docx_import / image
    state = load_project(PROJECT)
    state["mappings"]["project_name"] = {
        "kind": "scalar",
        "source_type": "text",
        "config": {"value": "Atlas-7 Modernization", "rich": False},
    }
    state["mappings"]["summary_section"] = {
        "kind": "scalar",
        "source_type": "docx_import",
        "config": {"filename": "embedded.docx"},
    }
    state["mappings"]["diagram"] = {
        "kind": "scalar",
        "source_type": "image",
        "config": {"filename": "diagram.png", "width_in": 3.0},
    }
    save_project(PROJECT, state)

    # 5. Render
    result = render_project(PROJECT)
    print(f"Rendered: {result.output_path}")
    print(f"Unmapped: {result.unmapped}")
    print(f"Errors:   {result.errors}")
    assert result.output_path.exists(),       "rendered file not created"
    assert not result.unmapped,               f"Unexpected unmapped: {result.unmapped}"
    assert not result.errors,                 f"Unexpected errors:   {result.errors}"

    # 6. Verify substitutions via the full XML
    out = Document(str(result.output_path))
    xml = out.element.xml
    assert "Atlas-7 Modernization" in xml,    "Text scalar missing"
    assert "Embedded Summary" in xml,         "docx_import Subdoc missing"
    # Image embed shows up as a relationship + a graphic element
    assert "graphicData" in xml,              "Image embed missing"
    assert "{{" not in xml,                   "Unrendered tags remaining"
    print("Substitution check: PASS")

    # 7. Section reset
    reset_tag(PROJECT, "summary_section")
    result2 = render_project(PROJECT)
    xml2 = Document(str(result2.output_path)).element.xml
    assert "[UNMAPPED: summary_section]" in xml2, "Reset didn't drop to placeholder"
    assert "Atlas-7 Modernization" in xml2,       "Other mappings should survive reset"
    print("Section reset: PASS")
    print("\nALL CHECKS PASSED.")


if __name__ == "__main__":
    main()
