// ============================================================================
// Native folder picker — wires Browse buttons up to /api/pick_directory.
// ============================================================================
document.querySelectorAll("button[data-pick-into]").forEach(btn => {
  btn.addEventListener("click", async () => {
    const targetId = btn.dataset.pickInto;
    const title = btn.dataset.pickTitle || "Select folder";
    const input = document.getElementById(targetId);
    const initial = input?.value || "";

    btn.disabled = true;
    const orig = btn.textContent;
    btn.textContent = "Opening...";

    try {
      const res = await fetch("/api/pick_directory", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ title, initial_dir: initial }),
      });
      const data = await res.json();
      if (data.ok && data.path) {
        if (input) {
          input.value = data.path;
          input.dispatchEvent(new Event("input", { bubbles: true }));
        }
      } else if (data.cancelled) {
        // user hit Cancel — silent
      } else if (data.error) {
        alert("Could not select folder: " + data.error);
      }
    } catch (e) {
      alert("Picker failed: " + e);
    } finally {
      btn.disabled = false;
      btn.textContent = orig;
    }
  });
});

// ============================================================================
// New-project preview: live "Will be created at: <parent>/<name>".
// ============================================================================
(function () {
  const previewEl = document.getElementById("create_preview");
  const parentEl = document.getElementById("create_parent");
  const nameEl = document.getElementById("create_name");
  if (!previewEl || !parentEl || !nameEl) return;

  function sep(p) {
    return p.includes("\\") && !p.includes("/") ? "\\" : "/";
  }
  function refresh() {
    const parent = parentEl.value.trim().replace(/[\/\\]+$/, "");
    const name = nameEl.value.trim();
    if (parent && name) {
      previewEl.textContent = parent + sep(parent || "/") + name;
    } else {
      previewEl.textContent = "—";
    }
  }
  parentEl.addEventListener("input", refresh);
  nameEl.addEventListener("input", refresh);
  refresh();
})();

// ============================================================================
// Tag editor: show/hide source-type fieldsets based on selected source type.
// ============================================================================
(function () {
  const select = document.getElementById("source_type");
  if (!select) return;

  function refresh() {
    const v = select.value;
    document.querySelectorAll("fieldset.src").forEach(fs => {
      fs.classList.toggle("active", fs.dataset.src === v);
    });
  }
  select.addEventListener("change", refresh);
  refresh();

  // Keyboard shortcut: Ctrl/Cmd+S to save the form.
  document.addEventListener("keydown", e => {
    if ((e.metaKey || e.ctrlKey) && e.key === "s") {
      const form = document.getElementById("tag-form");
      if (form) { e.preventDefault(); form.submit(); }
    }
  });
})();
