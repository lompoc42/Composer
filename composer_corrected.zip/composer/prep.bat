@echo off
REM prep.bat - Windows one-double-click setup.
REM Idempotent: organizes flat-downloaded files, creates .venv, installs deps.

cd /d "%~dp0"

echo ==^> Organizing files into the right folders...
if not exist adapters  mkdir adapters
if not exist templates mkdir templates
if not exist static    mkdir static
if not exist projects  mkdir projects
if not exist projects\.gitkeep type nul > projects\.gitkeep

for %%f in (__init__.py base.py text_adapter.py docx_import.py image_adapter.py) do (
    if exist "%%f" (
        move /Y "%%f" adapters\ >nul
        echo     moved %%f -^> adapters\
    )
)
for %%f in (base.html projects.html dashboard.html edit_tag.html) do (
    if exist "%%f" (
        move /Y "%%f" templates\ >nul
        echo     moved %%f -^> templates\
    )
)
for %%f in (app.js style.css) do (
    if exist "%%f" (
        move /Y "%%f" static\ >nul
        echo     moved %%f -^> static\
    )
)

REM Remove obsolete files from the previous version
for %%f in (xlsx_table.py csv_table.py) do (
    if exist "%%f"           (del /Q "%%f"           & echo     removed obsolete %%f)
    if exist "adapters\%%f"  (del /Q "adapters\%%f"  & echo     removed obsolete adapters\%%f)
)

echo.
echo ==^> Setting up virtual environment...
if not exist .venv (
    python -m venv .venv
    if errorlevel 1 (
        echo FAILED: could not create .venv. Is Python installed and on PATH?
        pause
        exit /b 1
    )
    echo     created .venv
) else (
    echo     .venv already exists
)

call .venv\Scripts\activate.bat

echo ==^> Installing dependencies (this may take a minute on first run)...
python -m pip install --upgrade pip --quiet
pip install -r requirements.txt --quiet

echo.
echo ====================================================
echo   Done. Double-click start.bat to launch.
echo ====================================================
echo.
pause
