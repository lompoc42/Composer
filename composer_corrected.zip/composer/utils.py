"""
Cross-platform utilities. Path handling, filename sanitization, atomic writes.
"""
from __future__ import annotations

import os
import re
import shutil
import unicodedata
from datetime import datetime, timezone
from pathlib import Path

# Characters illegal in Windows filenames (also includes control chars).
_BAD_FILENAME_CHARS = re.compile(r'[<>:"/\\|?*\x00-\x1f]')


def sanitize_filename(name: str, fallback: str = "untitled") -> str:
    """
    Make a filename that is legal on macOS, Linux, and Windows.

    Strips reserved chars, collapses whitespace, normalizes unicode.
    Never returns an empty string or a Windows reserved name.
    """
    name = unicodedata.normalize("NFKC", name).strip()
    name = _BAD_FILENAME_CHARS.sub("_", name)
    name = re.sub(r"\s+", " ", name)
    name = name.strip(". ")  # Windows hates trailing dot/space
    if not name:
        return fallback
    # Windows reserved device names (case-insensitive)
    reserved = {"CON", "PRN", "AUX", "NUL"}
    reserved |= {f"COM{i}" for i in range(1, 10)}
    reserved |= {f"LPT{i}" for i in range(1, 10)}
    stem = name.split(".")[0].upper()
    if stem in reserved:
        name = f"_{name}"
    return name


def now_iso() -> str:
    """UTC timestamp suitable for project.json."""
    return datetime.now(timezone.utc).isoformat(timespec="seconds")


def atomic_replace(src: Path, dst: Path) -> None:
    """
    Replace `dst` with `src`, atomically where possible.

    On Windows, if `dst` is open in Word, this will raise PermissionError.
    The render endpoint catches that and surfaces a clean message.
    """
    src = Path(src)
    dst = Path(dst)
    dst.parent.mkdir(parents=True, exist_ok=True)
    os.replace(src, dst)  # atomic on POSIX, atomic on Windows when possible


def safe_copy(src: Path, dst: Path) -> None:
    """Copy a file, creating parents. Used for stashing uploads in sources/."""
    dst.parent.mkdir(parents=True, exist_ok=True)
    shutil.copyfile(src, dst)
