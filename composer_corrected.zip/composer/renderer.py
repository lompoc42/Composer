"""
Render orchestrator.

Two passes around the docxtpl render call:

1. Pre-pass: for any tag mapped to a BLOCK-LEVEL adapter (currently
   docx_import), rewrite the inline ``{{tag}}`` to docxtpl's paragraph-scope
   form ``{{p tag}}``. docxtpl strips the surrounding ``<w:p>...</w:p>`` at
   patch_xml time, so the Subdoc XML lands at body level instead of being
   stuffed inside ``<w:t>`` (which produces malformed output where embedded
   tables ignore page geometry).

2. Post-pass: any table whose grid total exceeds the skeleton's content
   width gets scaled down proportionally — column widths, ``<w:tblW>``, and
   per-cell ``<w:tcW>`` all rescale by the same factor. This preserves the
   embedded doc's relative table layout while making it fit the skeleton's
   page.

Output filename is ``<project_name>.docx`` rather than the generic ``big.docx``.
"""
from __future__ import annotations

from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Dict, List, Set

from docx.oxml.ns import qn
from docxtpl import DocxTemplate

import adapters
from adapters.base import AdapterError, RenderContext
from config import SKELETON_FILENAME, UNMAPPED_PLACEHOLDER
from project_io import load_project, output_dir, project_dir, sources_dir
from utils import atomic_replace, sanitize_filename


# Adapter source types whose value is BLOCK-LEVEL (one or more whole
# paragraphs/tables). These need ``{{p tag}}`` syntax in the skeleton XML.
_BLOCK_LEVEL_SOURCES: Set[str] = {"docx_import"}


@dataclass
class RenderResult:
    output_path: Path
    unmapped: List[str]
    errors: List[str]
    warnings: List[str] = field(default_factory=list)


# ---------- helpers ---------------------------------------------------------

def _content_width_dxa(section) -> int:
    """Return printable content width of a section in dxa (1/20 pt).
    1 inch = 914400 EMU = 1440 dxa."""
    page_w = int(section.page_width or 0)
    ml = int(section.left_margin or 0)
    mr = int(section.right_margin or 0)
    content_emu = page_w - ml - mr
    if content_emu <= 0:
        return 0
    return int(round(content_emu / 914400 * 1440))


def _rewrite_block_tags(doc, block_tags: Set[str]) -> List[str]:
    """For each tag in block_tags, find paragraphs whose only content is
    ``{{tag}}`` and rewrite the run text to ``{{p tag}}``. Returns warnings
    for tags that appear inline alongside other text (which we can't safely
    paragraph-replace)."""
    warnings: List[str] = []
    for tag in block_tags:
        token = "{{" + tag + "}}"
        ptoken = "{{p " + tag + "}}"
        for p in doc.paragraphs:
            if token not in p.text:
                continue
            if p.text.strip() == token:
                # Concentrate the token into the first run, blank the rest,
                # so we don't end up with a token split across runs (which
                # would defeat the docxtpl regex).
                if p.runs:
                    p.runs[0].text = ptoken
                    for r in p.runs[1:]:
                        r.text = ""
                else:
                    p.add_run(ptoken)
            else:
                warnings.append(
                    f"Tag '{tag}' is mapped to a docx import but the "
                    f"paragraph contains other text too — embed will be "
                    f"malformed. Put the tag alone in its own paragraph."
                )
                break
    return warnings


def _clamp_oversized_tables(doc, max_dxa: int) -> int:
    """Scale every over-wide table down so its grid total fits within
    max_dxa. Preserves relative column proportions. Returns the count of
    tables modified."""
    if max_dxa <= 0:
        return 0
    clamped = 0
    for tbl_elem in doc.element.body.iter(qn("w:tbl")):
        grid = tbl_elem.find(qn("w:tblGrid"))
        if grid is None:
            continue
        cols = grid.findall(qn("w:gridCol"))
        if not cols:
            continue
        widths = []
        for c in cols:
            try:
                widths.append(int(c.get(qn("w:w")) or 0))
            except (TypeError, ValueError):
                widths.append(0)
        total = sum(widths)
        if total <= 0 or total <= max_dxa:
            continue
        scale = max_dxa / total
        for c, w in zip(cols, widths):
            c.set(qn("w:w"), str(max(1, int(w * scale))))
        # Overall table width hint
        tblPr = tbl_elem.find(qn("w:tblPr"))
        if tblPr is not None:
            tblW = tblPr.find(qn("w:tblW"))
            if tblW is not None:
                wval = tblW.get(qn("w:w"))
                if wval and wval.lstrip("-").isdigit():
                    n = int(wval)
                    if n > 0:
                        tblW.set(qn("w:w"), str(int(n * scale)))
                        tblW.set(qn("w:type"), "dxa")
        # Per-cell widths (handles merged cells via xpath iter)
        for tcW in tbl_elem.iter(qn("w:tcW")):
            wval = tcW.get(qn("w:w"))
            if not wval or not wval.lstrip("-").isdigit():
                continue
            n = int(wval)
            if n <= 0:
                continue
            tcW.set(qn("w:w"), str(max(1, int(n * scale))))
            tcW.set(qn("w:type"), "dxa")
        clamped += 1
    return clamped


def _output_filename(state: Dict[str, Any]) -> str:
    base = sanitize_filename(state.get("name") or "rendered")
    return f"{base}.docx"


# ---------- main -----------------------------------------------------------

def render_project(slug: str) -> RenderResult:
    state = load_project(slug)
    pdir = project_dir(slug)
    sdir = sources_dir(slug)
    odir = output_dir(slug)
    odir.mkdir(parents=True, exist_ok=True)

    skeleton = pdir / SKELETON_FILENAME
    if not skeleton.exists():
        raise FileNotFoundError(f"Skeleton missing: {skeleton}")

    tpl = DocxTemplate(str(skeleton))
    tpl.get_docx()  # force-load python-docx Document

    # Pre-pass: rewrite block-level tags to {{p tag}}.
    block_tags = {
        n for n, m in state.get("mappings", {}).items()
        if (m.get("source_type") or "") in _BLOCK_LEVEL_SOURCES
    }
    rewrite_warnings = _rewrite_block_tags(tpl.docx, block_tags)

    # Build context.
    ctx = RenderContext(project_dir=pdir, sources_dir=sdir, tpl=tpl)
    context: Dict[str, Any] = {}
    unmapped: List[str] = []
    errors: List[str] = []

    for tag_name, mapping in state.get("mappings", {}).items():
        source_type = mapping.get("source_type")
        config = mapping.get("config", {}) or {}
        if not source_type:
            context[tag_name] = UNMAPPED_PLACEHOLDER.format(tag=tag_name)
            unmapped.append(tag_name)
            continue
        try:
            adapter_cls = adapters.get(source_type)
            adapter_cls.validate(config)
            value = adapter_cls.render(config, ctx)
        except AdapterError as e:
            errors.append(f"{tag_name}: {e}")
            context[tag_name] = f"[ERROR: {tag_name}: {e}]"
            continue
        context[tag_name] = value

    tpl.render(context)

    # Post-pass: clamp tables that overflow the skeleton's page.
    clamped = 0
    if tpl.docx.sections:
        max_dxa = _content_width_dxa(tpl.docx.sections[0])
        clamped = _clamp_oversized_tables(tpl.docx, max_dxa)

    final_filename = _output_filename(state)
    tmp_filename = "." + final_filename + ".tmp"
    tmp_path = odir / tmp_filename
    final_path = odir / final_filename
    tpl.save(str(tmp_path))

    try:
        atomic_replace(tmp_path, final_path)
    except PermissionError:
        raise PermissionError(
            f"Could not write {final_path.name} — close it in Word and re-render. "
            f"Latest output is at {tmp_path.name}."
        )

    warnings = list(rewrite_warnings)
    if clamped:
        warnings.append(f"Resized {clamped} over-wide table(s) to fit the page.")

    return RenderResult(
        output_path=final_path,
        unmapped=unmapped,
        errors=errors,
        warnings=warnings,
    )
