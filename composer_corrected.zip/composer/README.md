# GUI 1 — Composer

Web UI that ingests a **tagged skeleton** `.docx`, lets you map every
`{{tag}}` to a data source (text, an embedded `.docx`, or an image), and
renders a finished **big doc**.

Once the big doc is rendered, GUI 1's job is done — the big doc is the
handoff to GUI 2 (Refresher) downstream.

## Quick start

### macOS (first run)

Because downloads don't preserve the executable bit, run prep once from
Terminal — after that, double-click works.

```
cd /path/to/gui1_composer
bash prep.command           # first time only; sets perms, organizes files,
                            # creates .venv, installs deps
```

After that, just **double-click** `start.command`.

### macOS (every run thereafter)

Double-click `start.command`. The browser opens to http://127.0.0.1:5050 once
the server is up.

### Windows

Double-click `prep.bat` once to set up. Then double-click `start.bat` to
launch.

## Re-editing a section after rendering

The big doc is a render artifact, **not** the source of truth. The persistent
state lives in the project folder:

```
projects/<project_name>/
    skeleton.docx         # the marked-up skeleton
    project.json          # tag catalog + per-tag mappings
    sources/              # uploaded source docs / images
    output/big.docx       # rendered final
```

To redo a section weeks later:

1. Launch the app and open the project — every previous mapping is still there.
2. Click **Reset** on the tag whose section you want to redo.
3. Click **Edit** on the same tag → drop in new content.
4. Click **Render big.docx**. The big doc rebuilds from scratch, with that one
   section changed and everything else intact.

You never feed the big doc back in. As long as you keep the project folder,
every section is independently swappable forever. **Keep the project folder
alongside the rendered big doc when archiving — the folder is what's editable.**

## Source types

- **Manual text** — type prose directly. Optional multi-paragraph mode splits
  on blank lines.
- **Word document (.docx)** — upload a `.docx`; embedded as a Subdoc preserving
  formatting.
- **Image** — upload an image, set width in inches.

## Workflow

1. **New project** — name it, upload the tagged skeleton `.docx`. The app
   scans it, builds the catalog, lists every tag with status `unmapped`.
2. **Edit each tag** — pick a source type, drop in content.
3. **Render big.docx** — every mapping runs, output written to
   `output/big.docx`. Unmapped tags render as visible `[UNMAPPED: <name>]`
   placeholders so gaps are obvious. Adapter errors render as
   `[ERROR: <tag>: <msg>]` and surface in the flash bar.
4. **Skeleton changed?** — Replace `skeleton.docx` and click **Rescan
   skeleton**. Mappings reconcile by tag name; removed tags are listed once.

## Cross-platform notes

- All paths use `pathlib.Path`. No hardcoded separators anywhere.
- `pip freeze`-pinned versions in `requirements.txt`. Reproduces identically
  on macOS and Windows.
- Project folders move between machines as plain folders — zip on Mac, unzip
  on Windows, mappings still resolve because every reference inside
  `project.json` is a basename relative to `sources/`.
- On Windows, if `big.docx` is open in Word during a render, the atomic
  rename fails cleanly with a clear error — close it and re-render.

## Adding a new source type

1. Drop a module under `adapters/` implementing `ScalarAdapter`.
2. Register it in `adapters/__init__.py` (`_REGISTRY`).
3. Add a matching `<fieldset class="src" data-src="<source_type>">` block in
   `templates/edit_tag.html`.

That's it — the dashboard, render endpoint, and reset all keep working.

## Known limits / future work

- No auth — bind to localhost only. Don't expose to the network as-is.
- In-GUI tag creation (highlight in preview → make a `{{tag}}`) is GUI 2
  territory.
