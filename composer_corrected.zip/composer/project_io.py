"""
Project state management. A project is one folder anywhere on disk.

A small registry file (<BASE_DIR>/.registry.json) maps URL-safe slugs to
absolute project paths so projects can live outside PROJECTS_DIR.

Folder layout (per project):
    <project_root>/
        skeleton.docx
        project.json
        sources/
        output/
            big.docx
            big.tmp.docx
"""
from __future__ import annotations

import json
import os
from pathlib import Path
from typing import Any, Dict, List, Tuple

from config import (
    BASE_DIR,
    OUTPUT_SUBDIR,
    PROJECT_JSON_FILENAME,
    PROJECTS_DIR,
    SKELETON_FILENAME,
    SOURCES_SUBDIR,
)
from utils import now_iso, sanitize_filename


REGISTRY_FILE = BASE_DIR / ".registry.json"


# ---------- registry ---------------------------------------------------------

def _load_registry() -> Dict[str, str]:
    if not REGISTRY_FILE.exists():
        return {}
    try:
        with REGISTRY_FILE.open("r", encoding="utf-8") as f:
            data = json.load(f)
        if not isinstance(data, dict):
            return {}
        return {str(k): str(v) for k, v in data.items()}
    except (json.JSONDecodeError, OSError):
        return {}


def _save_registry(reg: Dict[str, str]) -> None:
    REGISTRY_FILE.parent.mkdir(parents=True, exist_ok=True)
    tmp = REGISTRY_FILE.with_suffix(REGISTRY_FILE.suffix + ".tmp")
    with tmp.open("w", encoding="utf-8") as f:
        json.dump(reg, f, indent=2, ensure_ascii=False)
    os.replace(tmp, REGISTRY_FILE)


def _unique_slug(base: str, reg: Dict[str, str]) -> str:
    base = sanitize_filename(base)
    if base not in reg:
        return base
    i = 2
    while f"{base}-{i}" in reg:
        i += 1
    return f"{base}-{i}"


def _autoscan_default_dir(reg: Dict[str, str]) -> Dict[str, str]:
    """Backwards compat: any folder under PROJECTS_DIR with project.json gets
    registered if not already present."""
    if not PROJECTS_DIR.exists():
        return reg
    changed = False
    known_paths = {Path(v).resolve() for v in reg.values()}
    for p in sorted(PROJECTS_DIR.iterdir()):
        if not p.is_dir():
            continue
        if not (p / PROJECT_JSON_FILENAME).exists():
            continue
        if p.resolve() in known_paths:
            continue
        slug = _unique_slug(p.name, reg)
        reg[slug] = str(p.resolve())
        known_paths.add(p.resolve())
        changed = True
    if changed:
        _save_registry(reg)
    return reg


def register_path(path: Path, slug_hint: str | None = None) -> str:
    """Register a project folder; return its slug. If already registered,
    returns the existing slug."""
    reg = _load_registry()
    abs_path = Path(path).resolve()
    for s, p in reg.items():
        if Path(p).resolve() == abs_path:
            return s
    slug = _unique_slug(slug_hint or abs_path.name, reg)
    reg[slug] = str(abs_path)
    _save_registry(reg)
    return slug


def unregister(slug: str) -> None:
    reg = _load_registry()
    if reg.pop(slug, None) is not None:
        _save_registry(reg)


def all_registered() -> List[Dict[str, Any]]:
    """List of {slug, path, valid} dicts. `valid` is False if the folder is
    gone or no longer contains project.json (we keep the entry — the drive
    may come back)."""
    reg = _autoscan_default_dir(_load_registry())
    out = []
    for s in sorted(reg.keys()):
        p = Path(reg[s])
        out.append({
            "slug": s,
            "path": str(p),
            "valid": (p / PROJECT_JSON_FILENAME).exists(),
        })
    return out


# ---------- path lookup ------------------------------------------------------

def project_dir(slug: str) -> Path:
    reg = _autoscan_default_dir(_load_registry())
    if slug in reg:
        return Path(reg[slug])
    # Legacy fallback: bare folder under PROJECTS_DIR matching slug.
    return PROJECTS_DIR / sanitize_filename(slug)


def skeleton_path(slug: str) -> Path:
    return project_dir(slug) / SKELETON_FILENAME


def project_json_path(slug: str) -> Path:
    return project_dir(slug) / PROJECT_JSON_FILENAME


def sources_dir(slug: str) -> Path:
    return project_dir(slug) / SOURCES_SUBDIR


def output_dir(slug: str) -> Path:
    return project_dir(slug) / OUTPUT_SUBDIR


def list_projects() -> List[str]:
    return [r["slug"] for r in all_registered()]


def project_exists(slug: str) -> bool:
    return project_json_path(slug).exists()


# ---------- lifecycle --------------------------------------------------------

def init_project_at(parent_dir: Path, name: str, catalog: Dict[str, Any]) -> Tuple[str, Path]:
    """
    Scaffold a project at <parent_dir>/<sanitized name>/, register it,
    return (slug, project_root). Skeleton must already be at
    <project_root>/skeleton.docx.
    """
    safe_name = sanitize_filename(name)
    project_root = (Path(parent_dir) / safe_name).resolve()
    if not project_root.exists():
        raise FileNotFoundError(f"Project folder missing: {project_root}")
    if not (project_root / SKELETON_FILENAME).exists():
        raise FileNotFoundError(
            f"Skeleton not in place: expected {project_root / SKELETON_FILENAME}"
        )

    (project_root / SOURCES_SUBDIR).mkdir(parents=True, exist_ok=True)
    (project_root / OUTPUT_SUBDIR).mkdir(parents=True, exist_ok=True)

    # Register first so we know the actual slug (may be name-2 on collision).
    slug = register_path(project_root, slug_hint=safe_name)

    mappings: Dict[str, Any] = {}
    for s in catalog.get("scalars", []):
        mappings[s["name"]] = {
            "kind": "scalar",
            "source_type": None,
            "config": {},
        }

    state = {
        "name": slug,                     # slug == display name; kept in sync
        "skeleton_filename": SKELETON_FILENAME,
        "created_at": now_iso(),
        "updated_at": now_iso(),
        "catalog": catalog,
        "mappings": mappings,
    }
    save_project(slug, state)
    return slug, project_root


def init_project(name: str, catalog: Dict[str, Any]) -> Dict[str, Any]:
    """Legacy entry point used by smoke_test: scaffold under PROJECTS_DIR."""
    safe = sanitize_filename(name)
    project_root = PROJECTS_DIR / safe
    project_root.mkdir(parents=True, exist_ok=True)
    slug, _ = init_project_at(PROJECTS_DIR, name, catalog)
    return load_project(slug)


def open_existing(path: Path) -> str:
    """Validate that `path` is a project folder, register it, return slug."""
    abs_path = Path(path).expanduser().resolve()
    if not abs_path.is_dir():
        raise FileNotFoundError(f"Not a directory: {abs_path}")
    if not (abs_path / PROJECT_JSON_FILENAME).exists():
        raise FileNotFoundError(
            f"No {PROJECT_JSON_FILENAME} in {abs_path} — not a Composer project."
        )
    return register_path(abs_path)


def load_project(slug: str) -> Dict[str, Any]:
    p = project_json_path(slug)
    if not p.exists():
        raise FileNotFoundError(f"No project at {p}")
    with p.open("r", encoding="utf-8") as f:
        return json.load(f)


def save_project(slug: str, state: Dict[str, Any]) -> None:
    state["updated_at"] = now_iso()
    p = project_json_path(slug)
    p.parent.mkdir(parents=True, exist_ok=True)
    tmp = p.with_suffix(p.suffix + ".tmp")
    with tmp.open("w", encoding="utf-8") as f:
        json.dump(state, f, indent=2, ensure_ascii=False)
    os.replace(tmp, p)


def reconcile_with_skeleton(slug: str, new_catalog: Dict[str, Any]) -> Dict[str, Any]:
    state = load_project(slug)
    old = state.get("mappings", {})
    new_names = {s["name"] for s in new_catalog.get("scalars", [])}

    new_mappings: Dict[str, Any] = {}
    for s in new_catalog.get("scalars", []):
        new_mappings[s["name"]] = old.get(s["name"], {
            "kind": "scalar",
            "source_type": None,
            "config": {},
        })
        new_mappings[s["name"]]["kind"] = "scalar"

    removed = [n for n in old if n not in new_names and old[n].get("source_type")]
    state["catalog"] = new_catalog
    state["mappings"] = new_mappings
    state["last_removed_tags"] = removed
    save_project(slug, state)
    return state


def reset_tag(slug: str, tag: str) -> Dict[str, Any]:
    state = load_project(slug)
    if tag not in state["mappings"]:
        raise KeyError(f"Unknown tag: {tag}")
    m = state["mappings"][tag]
    m["source_type"] = None
    m["config"] = {}
    save_project(slug, state)
    return state
