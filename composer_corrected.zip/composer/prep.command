#!/bin/bash
# prep.command — macOS one-double-click setup.
# Idempotent: organizes flat-downloaded files, creates the .venv, installs deps.
# Re-run anytime; it will skip steps already done.

# Anchor to this script's directory regardless of where it was launched from.
cd "$(dirname "$0")" || exit 1

# Make ourselves and start.command executable so future double-clicks work.
chmod +x prep.command start.command 2>/dev/null || true

echo "==> Organizing files into the right folders..."
mkdir -p adapters templates static projects
[ -f projects/.gitkeep ] || touch projects/.gitkeep

move_if_present() {
    local target="$1"; shift
    for f in "$@"; do
        if [ -f "./$f" ]; then
            mv "./$f" "$target/"
            echo "    moved $f -> $target/"
        fi
    done
}

move_if_present adapters \
    __init__.py base.py text_adapter.py docx_import.py image_adapter.py
move_if_present templates \
    base.html projects.html dashboard.html edit_tag.html
move_if_present static \
    app.js style.css

# Remove obsolete files from the previous version, in case they're hanging around.
for f in xlsx_table.py csv_table.py adapters/xlsx_table.py adapters/csv_table.py; do
    if [ -f "$f" ]; then
        rm -f "$f"
        echo "    removed obsolete $f"
    fi
done

echo ""
echo "==> Setting up virtual environment..."
PYTHON="${PYTHON:-python3}"
if [ ! -d ".venv" ]; then
    "$PYTHON" -m venv .venv || { echo "FAILED: could not create .venv. Is python3 installed?"; exit 1; }
    echo "    created .venv"
else
    echo "    .venv already exists"
fi

# shellcheck source=/dev/null
source .venv/bin/activate

echo "==> Installing dependencies (this may take a minute on first run)..."
python -m pip install --upgrade pip --quiet
pip install -r requirements.txt --quiet

echo ""
echo "===================================================="
echo "  Done. Double-click start.command to launch."
echo "===================================================="
echo ""
echo "Press any key to close this window..."
read -n 1 -s
