"""
Skeleton scanner: extract every {{tag}} from a .docx without rendering.

Only flat scalar tags are recognized. Loop blocks ({% for ... %}) and dotted
tags are out of scope for GUI 1 — keep skeletons simple.
"""
from __future__ import annotations

import re
from dataclasses import dataclass, asdict
from pathlib import Path
from typing import List, Dict, Any

from docx import Document

# Jinja2 variable reference, e.g. {{ foo }}.
# Stops at | so filters get stripped (we discard them).
_VAR_RE = re.compile(r"\{\{\s*([^}{|]+?)\s*(?:\|[^}]*)?\}\}")


@dataclass
class ScalarTag:
    name: str

    def to_dict(self) -> Dict[str, Any]:
        d = asdict(self)
        d["kind"] = "scalar"
        return d


def _full_text(doc: Document) -> str:
    """
    Concatenate every block of text in the doc (paragraphs, table cells,
    headers, footers) so we don't miss tags placed anywhere.
    """
    chunks: List[str] = []
    for p in doc.paragraphs:
        chunks.append(p.text)
    for tbl in doc.tables:
        for row in tbl.rows:
            for cell in row.cells:
                for p in cell.paragraphs:
                    chunks.append(p.text)
    for section in doc.sections:
        for hf in (section.header, section.footer):
            for p in hf.paragraphs:
                chunks.append(p.text)
    return "\n".join(chunks)


def scan_skeleton(skeleton_path: Path) -> Dict[str, Any]:
    """
    Open a skeleton .docx and return a catalog of every tag found.

    Returns:
        {
          "scalars":   [ScalarTag, ...]   # as dicts
          "all_names": [str, ...]
        }
    """
    skeleton_path = Path(skeleton_path)
    doc = Document(str(skeleton_path))
    text = _full_text(doc)

    scalars: List[ScalarTag] = []
    seen: set = set()
    for m in _VAR_RE.finditer(text):
        name = m.group(1).strip()
        if not name or name in seen:
            continue
        # Filter out anything that looks like a function call or filter
        if "(" in name:
            continue
        seen.add(name)
        scalars.append(ScalarTag(name=name))

    return {
        "scalars":   [s.to_dict() for s in scalars],
        "all_names": [s.name for s in scalars],
    }
