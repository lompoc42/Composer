"""
Central configuration. No argparse, hardcoded-but-portable paths.

All paths are derived from BASE_DIR so the project works identically on
macOS dev box and Windows deploy box.
"""
from pathlib import Path

BASE_DIR = Path(__file__).resolve().parent
PROJECTS_DIR = BASE_DIR / "projects"

# Per-project subfolder layout (relative to PROJECTS_DIR / <project_name>)
SKELETON_FILENAME = "skeleton.docx"
PROJECT_JSON_FILENAME = "project.json"
SOURCES_SUBDIR = "sources"
OUTPUT_SUBDIR = "output"
# Rendered output filename is derived from the project name at render time
# (see renderer._output_filename), so no global constant for it.

# Flask runtime
HOST = "127.0.0.1"
PORT = 5050
DEBUG = True

# Upload size cap (50 MB). Raise if your sources are larger.
MAX_UPLOAD_BYTES = 50 * 1024 * 1024

# Placeholder text injected for unmapped scalar tags so missing data is
# obvious in the rendered big doc rather than rendering blank.
UNMAPPED_PLACEHOLDER = "[UNMAPPED: {tag}]"
