"""
Embed an external .docx into the big doc, preserving its native formatting.

This is the right adapter for "I have a finished section in another Word
document — drop it in here." docxtpl's Subdoc mechanism handles cross-doc
style merging cleanly.

config:
    { "filename": "<basename under sources/>" }
"""
from __future__ import annotations

from pathlib import Path
from typing import Any, Dict

from .base import ScalarAdapter, RenderContext, AdapterError


class DocxImportAdapter(ScalarAdapter):
    SOURCE_TYPE = "docx_import"
    LABEL = "Word document (.docx)"

    @classmethod
    def validate(cls, config: Dict[str, Any]) -> None:
        fn = config.get("filename")
        if not fn:
            raise AdapterError("docx_import: missing 'filename'")
        if not str(fn).lower().endswith(".docx"):
            raise AdapterError("docx_import: file must be .docx")

    @classmethod
    def render(cls, config: Dict[str, Any], ctx: RenderContext) -> Any:
        path = ctx.sources_dir / config["filename"]
        if not path.exists():
            raise AdapterError(f"docx_import: file not found: {path}")
        sub = ctx.tpl.new_subdoc(str(path))
        return sub
