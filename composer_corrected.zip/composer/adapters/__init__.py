"""
Adapter registry. Each adapter knows how to:
  - Validate its config dict (raises AdapterError on bad config)
  - Render itself into the docxtpl context as a value the template expects:
      scalar adapters return: str | RichText | Subdoc | InlineImage

To add a new source type:
  1. Drop a module under adapters/ implementing the Adapter ABC.
  2. Register the class in `_REGISTRY` below.
  3. Add a corresponding form fragment in templates/edit_tag.html.
"""
from __future__ import annotations

from typing import Dict, Type

from .base import Adapter, AdapterError, ScalarAdapter, LoopAdapter
from .text_adapter import TextAdapter
from .docx_import import DocxImportAdapter
from .image_adapter import ImageAdapter

_REGISTRY: Dict[str, Type[Adapter]] = {
    TextAdapter.SOURCE_TYPE: TextAdapter,
    DocxImportAdapter.SOURCE_TYPE: DocxImportAdapter,
    ImageAdapter.SOURCE_TYPE: ImageAdapter,
}


def get(source_type: str) -> Type[Adapter]:
    if source_type not in _REGISTRY:
        raise AdapterError(f"Unknown source_type: {source_type!r}")
    return _REGISTRY[source_type]


def available_for_kind(kind: str) -> list:
    """List adapters that match a tag kind. Only 'scalar' returns anything in v1."""
    out = []
    for st, cls in _REGISTRY.items():
        if kind == "scalar" and issubclass(cls, ScalarAdapter):
            out.append({"source_type": st, "label": cls.LABEL})
    return out


__all__ = ["Adapter", "AdapterError", "get", "available_for_kind"]
