"""
Insert an image at a {{tag}} location.

config:
    {
      "filename": "<basename under sources/>",
      "width_in": 4.5      # optional, defaults to 4.0 inches if omitted
    }
"""
from __future__ import annotations

from typing import Any, Dict

from docx.shared import Inches
from docxtpl import InlineImage

from .base import ScalarAdapter, RenderContext, AdapterError

_OK_EXT = {".png", ".jpg", ".jpeg", ".gif", ".bmp", ".tif", ".tiff"}


class ImageAdapter(ScalarAdapter):
    SOURCE_TYPE = "image"
    LABEL = "Image"

    @classmethod
    def validate(cls, config: Dict[str, Any]) -> None:
        fn = config.get("filename")
        if not fn:
            raise AdapterError("image: missing 'filename'")
        ext = "." + str(fn).rsplit(".", 1)[-1].lower() if "." in str(fn) else ""
        if ext not in _OK_EXT:
            raise AdapterError(f"image: unsupported extension {ext!r}")
        w = config.get("width_in", 4.0)
        try:
            w = float(w)
        except (TypeError, ValueError):
            raise AdapterError("image: 'width_in' must be a number")
        if w <= 0 or w > 20:
            raise AdapterError("image: 'width_in' must be between 0 and 20")

    @classmethod
    def render(cls, config: Dict[str, Any], ctx: RenderContext) -> Any:
        path = ctx.sources_dir / config["filename"]
        if not path.exists():
            raise AdapterError(f"image: file not found: {path}")
        width_in = float(config.get("width_in", 4.0))
        return InlineImage(ctx.tpl, str(path), width=Inches(width_in))
