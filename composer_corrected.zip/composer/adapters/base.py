"""
Base classes for source adapters.

Adapters take a per-tag config dict + a render context (project paths and the
docxtpl template) and produce the value that gets injected into the Jinja
context for the final render.
"""
from __future__ import annotations

from abc import ABC, abstractmethod
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Dict, List


class AdapterError(Exception):
    """Raised on bad config or unrecoverable adapter input."""


@dataclass
class RenderContext:
    """Everything an adapter needs to do its job at render time."""
    project_dir: Path
    sources_dir: Path
    tpl: Any  # docxtpl.DocxTemplate — typed Any to keep this module import-light


class Adapter(ABC):
    SOURCE_TYPE: str = ""   # registry key, e.g. "text"
    LABEL: str = ""         # human-readable label for the GUI dropdown

    @classmethod
    @abstractmethod
    def validate(cls, config: Dict[str, Any]) -> None:
        """Raise AdapterError if config is malformed or refers to missing files."""

    @classmethod
    @abstractmethod
    def render(cls, config: Dict[str, Any], ctx: RenderContext) -> Any:
        """Produce the value that goes into the Jinja context for this tag."""


class ScalarAdapter(Adapter):
    """Adapter that yields a single value for a {{var}} tag."""


class LoopAdapter(Adapter):
    """Adapter that yields a list[dict] for a {% for x in expr %} tag."""

    @classmethod
    @abstractmethod
    def render(cls, config: Dict[str, Any], ctx: RenderContext) -> List[Dict[str, Any]]:
        ...
