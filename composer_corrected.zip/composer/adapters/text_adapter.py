"""
Manual text adapter. The simplest case: user types prose in the GUI.

config:
    {
      "value": "<the text the user typed>",
      "rich": false      # if true, treat newlines as paragraph breaks via RichText
    }
"""
from __future__ import annotations

from typing import Any, Dict

from docxtpl import RichText

from .base import ScalarAdapter, RenderContext, AdapterError


class TextAdapter(ScalarAdapter):
    SOURCE_TYPE = "text"
    LABEL = "Manual text"

    @classmethod
    def validate(cls, config: Dict[str, Any]) -> None:
        if "value" not in config:
            raise AdapterError("text adapter: missing 'value'")
        if not isinstance(config["value"], str):
            raise AdapterError("text adapter: 'value' must be a string")

    @classmethod
    def render(cls, config: Dict[str, Any], ctx: RenderContext) -> Any:
        text = config["value"]
        if not config.get("rich"):
            return text
        # Multi-paragraph rendering: split on blank lines, emit RichText with
        # paragraph breaks so Word treats each chunk as its own paragraph.
        rt = RichText("")
        first = True
        for para in text.split("\n\n"):
            if not first:
                rt.add("\n\n")
            rt.add(para)
            first = False
        return rt
