@echo off
REM start.bat - Windows launcher.

cd /d "%~dp0"

if not exist .venv (
    echo ERROR: .venv not found. Run prep.bat first.
    pause
    exit /b 1
)

call .venv\Scripts\activate.bat

REM Open the default browser; Flask will bind in a moment.
start "" http://127.0.0.1:5050

python app.py
